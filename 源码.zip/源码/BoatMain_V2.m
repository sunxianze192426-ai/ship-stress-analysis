classdef BoatMain_V2 < matlab.apps.AppBase

    % ================================================================
    % PROPERTIES - PUBLIC (All UI Components for Tab_1 ~ Tab_6)
    % ================================================================
    properties (Access = public)
        UIFigure        matlab.ui.Figure
        TabGroup        matlab.ui.container.TabGroup

        % ================== Tab_1: 振动剖面 ==================
        Tab             matlab.ui.container.Tab
        Button          matlab.ui.control.Button
        EditField       matlab.ui.control.EditField
        iLabel          matlab.ui.control.Label
        iEditField      matlab.ui.control.NumericEditField
        Button_2        matlab.ui.control.Button
        HzEditField_2Label matlab.ui.control.Label
        HzEditField_2   matlab.ui.control.NumericEditField
        Label           matlab.ui.control.Label
        EditField_2     matlab.ui.control.NumericEditField
        Label_2         matlab.ui.control.Label
        EditField_3     matlab.ui.control.NumericEditField
        Label_3         matlab.ui.control.Label
        Button_3        matlab.ui.control.Button
        Button_4        matlab.ui.control.Button
        Button_5        matlab.ui.control.Button
        Button_6        matlab.ui.control.Button
        Label_4         matlab.ui.control.Label
        Label_5         matlab.ui.control.Label
        EditField_4     matlab.ui.control.NumericEditField
        Label_6         matlab.ui.control.Label
        EditField_5     matlab.ui.control.NumericEditField
        Label_7         matlab.ui.control.Label
        HzLabel         matlab.ui.control.Label
        Label_8         matlab.ui.control.Label
        HzLabel_2       matlab.ui.control.Label
        Label_9         matlab.ui.control.Label
        HzLabel_3       matlab.ui.control.Label
        Label_10        matlab.ui.control.Label
        HzLabel_4       matlab.ui.control.Label
        ms22HzLabel     matlab.ui.control.Label
        Label_42        matlab.ui.control.Label
        Image           matlab.ui.control.Image
        UIAxes2         matlab.ui.control.UIAxes
        UIAxes2_2       matlab.ui.control.UIAxes
        UIAxes2_3       matlab.ui.control.UIAxes
        UIAxes2_4       matlab.ui.control.UIAxes
        UIAxes2_5       matlab.ui.control.UIAxes
        UIAxes2_6       matlab.ui.control.UIAxes

        % ================== Tab_2: 冲击剖面 ==================
        Tab_2           matlab.ui.container.Tab
        Button_7        matlab.ui.control.Button
        EditField_6     matlab.ui.control.EditField
        Button_8        matlab.ui.control.Button
        Label_11        matlab.ui.control.Label
        Button_9        matlab.ui.control.Button
        iEditField_2Label matlab.ui.control.Label
        iEditField_2    matlab.ui.control.NumericEditField
        HzEditField_3Label matlab.ui.control.Label
        HzEditField_3   matlab.ui.control.NumericEditField
        Label_12        matlab.ui.control.Label
        EditField_9     matlab.ui.control.NumericEditField
        Label_13        matlab.ui.control.Label
        EditField_8     matlab.ui.control.NumericEditField
        inEditFieldLabel matlab.ui.control.Label
        inEditField     matlab.ui.control.NumericEditField
        Label_14        matlab.ui.control.Label
        Label_15        matlab.ui.control.Label
        Label_16        matlab.ui.control.Label
        EditField_10    matlab.ui.control.NumericEditField
        HzLabel_5       matlab.ui.control.Label
        Label_18        matlab.ui.control.Label
        SRSgLabel       matlab.ui.control.Label
        Label_41        matlab.ui.control.Label
        Image_2         matlab.ui.control.Image
        UIAxes2_7       matlab.ui.control.UIAxes
        UIAxes2_8       matlab.ui.control.UIAxes
        UIAxes2_9       matlab.ui.control.UIAxes

        % ================== Tab_3: 温湿度剖面1 ==================
        Tab_3           matlab.ui.container.Tab
        Button_10       matlab.ui.control.Button
        EditField_11    matlab.ui.control.EditField
        i1EditFieldLabel matlab.ui.control.Label
        i1EditField     matlab.ui.control.NumericEditField
        Button_11       matlab.ui.control.Button
        i2EditFieldLabel matlab.ui.control.Label
        i2EditField     matlab.ui.control.NumericEditField
        hEditFieldLabel matlab.ui.control.Label
        hEditField      matlab.ui.control.NumericEditField
        EditField_12Label matlab.ui.control.Label
        EditField_12    matlab.ui.control.NumericEditField
        EditField_13Label matlab.ui.control.Label
        EditField_13    matlab.ui.control.NumericEditField
        Label_39        matlab.ui.control.Label
        Image_3         matlab.ui.control.Image
        UIAxes10        matlab.ui.control.UIAxes
        UIAxes10_2      matlab.ui.control.UIAxes
        UIAxes10_4      matlab.ui.control.UIAxes
        UIAxes10_6      matlab.ui.control.UIAxes
        UIAxes10_7      matlab.ui.control.UIAxes
        UIAxes10_8      matlab.ui.control.UIAxes
        UIAxes10_9      matlab.ui.control.UIAxes

        % ================== Tab_4: 温湿度剖面2 ==================
        Tab_4           matlab.ui.container.Tab
        Label_19        matlab.ui.control.Label
        Label_20        matlab.ui.control.Label
        Label_21        matlab.ui.control.Label
        Label_22        matlab.ui.control.Label
        Label_23        matlab.ui.control.Label
        Label_24        matlab.ui.control.Label
        Label_25        matlab.ui.control.Label
        Label_26        matlab.ui.control.Label
        Label_27        matlab.ui.control.Label
        Label_28        matlab.ui.control.Label
        Label_29        matlab.ui.control.Label
        Label_30        matlab.ui.control.Label
        Label_31        matlab.ui.control.Label
        Label_32        matlab.ui.control.Label
        Label_33        matlab.ui.control.Label
        Label_34        matlab.ui.control.Label
        Label_36        matlab.ui.control.Label
        Label_37        matlab.ui.control.Label
        Label_38        matlab.ui.control.Label
        Label_40        matlab.ui.control.Label
        Image_4         matlab.ui.control.Image
        Label_43        matlab.ui.control.Label
        Label_44        matlab.ui.control.Label
        UIAxes10_10     matlab.ui.control.UIAxes
        UIAxes10_11     matlab.ui.control.UIAxes
        UIAxes10_12     matlab.ui.control.UIAxes
        UIAxes10_13     matlab.ui.control.UIAxes
        UIAxes10_14     matlab.ui.control.UIAxes

        % ================== Tab_5: 倾角剖面 ==================
        Tab_5           matlab.ui.container.Tab
        Button_12       matlab.ui.control.Button
        EditField_14    matlab.ui.control.EditField
        xButton         matlab.ui.control.Button
        xi1Label        matlab.ui.control.Label
        xi1EditField    matlab.ui.control.NumericEditField
        yi2EditFieldLabel matlab.ui.control.Label
        yi2EditField    matlab.ui.control.NumericEditField
        zi3EditFieldLabel matlab.ui.control.Label
        zi3EditField    matlab.ui.control.NumericEditField
        EditField_15Label matlab.ui.control.Label
        EditField_15    matlab.ui.control.NumericEditField
        fsEditFieldLabel matlab.ui.control.Label
        fsEditField     matlab.ui.control.NumericEditField
        Label_45        matlab.ui.control.Label
        EditField_16    matlab.ui.control.NumericEditField
        yButton         matlab.ui.control.Button
        zButton         matlab.ui.control.Button
        Label_46        matlab.ui.control.Label
        Image_5         matlab.ui.control.Image
        Label_47        matlab.ui.control.Label
        Label_48        matlab.ui.control.Label
        sLabel          matlab.ui.control.Label
        Label_50        matlab.ui.control.Label
        Label_51        matlab.ui.control.Label
        Label_52        matlab.ui.control.Label
        sLabel_2        matlab.ui.control.Label
        Label_53        matlab.ui.control.Label
        Label_54        matlab.ui.control.Label
        Label_55        matlab.ui.control.Label
        sLabel_3        matlab.ui.control.Label
        Label_56        matlab.ui.control.Label
        UIAxes10_15     matlab.ui.control.UIAxes
        UIAxes10_16     matlab.ui.control.UIAxes
        UIAxes10_17     matlab.ui.control.UIAxes
        UIAxes10_18     matlab.ui.control.UIAxes
        UIAxes10_19     matlab.ui.control.UIAxes
        UIAxes10_20     matlab.ui.control.UIAxes
        UIAxes10_21     matlab.ui.control.UIAxes
        UIAxes10_22     matlab.ui.control.UIAxes
        UIAxes10_23     matlab.ui.control.UIAxes

        % ================== Tab_6: 设备应力综合分析 (NEW V2.0) ==================
        Tab_6           matlab.ui.container.Tab
        Label_74        matlab.ui.control.Label
        Image_7         matlab.ui.control.Image
        Label_76        matlab.ui.control.Label
        Button_17       matlab.ui.control.Button
        EditField_17    matlab.ui.control.EditField
        Label_57        matlab.ui.control.Label
        Button_18       matlab.ui.control.Button
        Label_58        matlab.ui.control.Label
        ListBox_1       matlab.ui.control.ListBox
        Label_73        matlab.ui.control.Label
        EditField_18    matlab.ui.control.NumericEditField
        EditField_19    matlab.ui.control.NumericEditField
        Label_59        matlab.ui.control.Label
        Label_60        matlab.ui.control.Label
        Button_19       matlab.ui.control.Button
        Button_20       matlab.ui.control.Button
        Button_25       matlab.ui.control.Button
        UIAxes_24       matlab.ui.control.UIAxes
        UIAxes_25       matlab.ui.control.UIAxes
        UITable_2       matlab.ui.control.Table
        Label_61        matlab.ui.control.Label
        Label_62        matlab.ui.control.Label
        Label_63        matlab.ui.control.Label
        Label_64        matlab.ui.control.Label
        Label_66        matlab.ui.control.Label
        Label_75        matlab.ui.control.Label

        % ================== Tab_7: 蒸汽流量 ==================
        Tab_7           matlab.ui.container.Tab
        Label_78        matlab.ui.control.Label
        Image_8         matlab.ui.control.Image
        Label_79        matlab.ui.control.Label
        Button_26       matlab.ui.control.Button
        EditField_20    matlab.ui.control.EditField
        Label_200       matlab.ui.control.Label
        Button_27       matlab.ui.control.Button
        Label_201       matlab.ui.control.Label
        ListBox_2       matlab.ui.control.ListBox
        Label_80        matlab.ui.control.Label
        EditField_28    matlab.ui.control.NumericEditField
        EditField_29    matlab.ui.control.NumericEditField
        Label_202       matlab.ui.control.Label
        Label_203       matlab.ui.control.Label
        Button_28       matlab.ui.control.Button
        Button_29       matlab.ui.control.Button
        Button_30       matlab.ui.control.Button
        UIAxes_26       matlab.ui.control.UIAxes
        UIAxes_27       matlab.ui.control.UIAxes
        UITable_3       matlab.ui.control.Table
        Label_67        matlab.ui.control.Label
        Label_68        matlab.ui.control.Label
        Label_69        matlab.ui.control.Label
        Label_70        matlab.ui.control.Label
        Label_71        matlab.ui.control.Label

        % ================== Tab_8: 蒸汽颗粒物浓度 ==================
        Tab_8           matlab.ui.container.Tab
        Label_82        matlab.ui.control.Label
        Image_9         matlab.ui.control.Image
        Label_83        matlab.ui.control.Label
        Button_31       matlab.ui.control.Button
        EditField_21    matlab.ui.control.EditField
        Label_204       matlab.ui.control.Label
        Button_32       matlab.ui.control.Button
        Label_205       matlab.ui.control.Label
        ListBox_3       matlab.ui.control.ListBox
        Label_84        matlab.ui.control.Label
        EditField_31    matlab.ui.control.NumericEditField
        EditField_32    matlab.ui.control.NumericEditField
        Label_206       matlab.ui.control.Label
        Label_207       matlab.ui.control.Label
        Button_33       matlab.ui.control.Button
        Button_34       matlab.ui.control.Button
        Button_35       matlab.ui.control.Button
        UIAxes_28       matlab.ui.control.UIAxes
        UIAxes_29       matlab.ui.control.UIAxes
        UITable_4       matlab.ui.control.Table
        Label_72        matlab.ui.control.Label
        Label_208       matlab.ui.control.Label
        Label_209       matlab.ui.control.Label
        Label_210       matlab.ui.control.Label
        Label_211       matlab.ui.control.Label

        % ================== Tab_9: 盐雾浓度 ==================
        Tab_9           matlab.ui.container.Tab
        Label_86        matlab.ui.control.Label
        Image_10        matlab.ui.control.Image
        Label_87        matlab.ui.control.Label
        Button_36       matlab.ui.control.Button
        EditField_22    matlab.ui.control.EditField
        Label_212       matlab.ui.control.Label
        Button_37       matlab.ui.control.Button
        Label_213       matlab.ui.control.Label
        ListBox_4       matlab.ui.control.ListBox
        Label_88        matlab.ui.control.Label
        EditField_33    matlab.ui.control.NumericEditField
        EditField_34    matlab.ui.control.NumericEditField
        Label_214       matlab.ui.control.Label
        Label_215       matlab.ui.control.Label
        Button_38       matlab.ui.control.Button
        Button_39       matlab.ui.control.Button
        Button_40       matlab.ui.control.Button
        UIAxes_30       matlab.ui.control.UIAxes
        UIAxes_31       matlab.ui.control.UIAxes
        UITable_5       matlab.ui.control.Table
        Label_77        matlab.ui.control.Label
        Label_216       matlab.ui.control.Label
        Label_217       matlab.ui.control.Label
        Label_218       matlab.ui.control.Label
        Label_219       matlab.ui.control.Label

        % ================== Tab_10: 氧浓度 ==================
        Tab_10          matlab.ui.container.Tab
        Label_90        matlab.ui.control.Label
        Image_11        matlab.ui.control.Image
        Label_91        matlab.ui.control.Label
        Button_41       matlab.ui.control.Button
        EditField_23    matlab.ui.control.EditField
        Label_220       matlab.ui.control.Label
        Button_42       matlab.ui.control.Button
        Label_221       matlab.ui.control.Label
        ListBox_5       matlab.ui.control.ListBox
        Label_92        matlab.ui.control.Label
        EditField_35    matlab.ui.control.NumericEditField
        EditField_36    matlab.ui.control.NumericEditField
        Label_222       matlab.ui.control.Label
        Label_223       matlab.ui.control.Label
        Button_43       matlab.ui.control.Button
        Button_44       matlab.ui.control.Button
        Button_45       matlab.ui.control.Button
        UIAxes_32       matlab.ui.control.UIAxes
        UIAxes_33       matlab.ui.control.UIAxes
        UITable_6       matlab.ui.control.Table
        Label_222_t10   matlab.ui.control.Label
        Label_223_t10   matlab.ui.control.Label
        Label_224       matlab.ui.control.Label
        Label_225       matlab.ui.control.Label
        Label_226       matlab.ui.control.Label
    end

    % ================================================================
    % PROPERTIES - PRIVATE (Tab_6~Tab_10 State, indexed 1..5)
    % ================================================================
    properties (Access = private)
        TabState  struct = struct(...
            'Loaded',   {false, false, false, false, false}, ...
            'Param',    {'蒸汽压力','蒸汽流量','蒸汽颗粒物浓度','盐雾浓度','氧浓度'}, ...
            'Unit',     {'MPa','m3/h','%','mg/m3','%'}, ...
            'File',     {'','','','',''}, ...
            'Tags',     {{},{},{},{},{}}, ...
            'Values',   {[], [], [], [], []}, ...
            'Units',    {{},{},{},{},{}}, ...
            'CatNames', {{},{},{},{},{}}, ...
            'Stats',    {table(), table(), table(), table(), table()})
        curTabIdx   double = 1
    end

    % ================================================================
    % CALLBACKS - Tab_1: 振动剖面
    % ================================================================
    methods (Access = private)

        function ButtonPushed(app, src, event)
            [filename, filepath] = uigetfile('*.*', '请选择文件');
            app.EditField.Value = [filepath, filename];
        end

        function Button_2Pushed2(app, src, event)
            fullFilePath = fullfile(app.EditField.Value);
            data = xlsread(fullFilePath);
            i1 = app.iEditField.Value;
            n11 = app.HzEditField_2.Value;
            if i1 >= 1 && i1 <= size(data, 2)
                columnData = data(:, i1);
                n12 = app.EditField_4.Value;
                n2 = n11 * n12;
                n1 = length(columnData);
                t1 = 1/n2:1/n2:n1/n2;
                plot(app.UIAxes2, t1, columnData);
            else
                errordlg('无效的列号，请输入有效的列号。', '错误', 'modal');
            end
        end

        function iEditFieldValueChanged2(app, src, event)
        end

        function EditField_2ValueChanged(app, src, event)
        end

        function EditField_3ValueChanged(app, src, event)
        end

        function UIAxes2_2ButtonDown(app, src, event)
        end

        function Button_3Pushed(app, src, event)
            lup = app.EditField_2.Value;
            ldn = app.EditField_3.Value;
            range = sprintf(' A%d:Z%d ', lup, ldn);
            fullFilePath = fullfile(app.EditField.Value);
            columnData = xlsread(fullFilePath, range);
            i1 = app.iEditField.Value;
            dataC = columnData(:, i1);
            fd = app.EditField_4.Value;
            dataB = reshape(dataC, fd, (ldn-lup+1)/fd)';
            num = fd;
            px = app.EditField_5.Value;
            for ii = 1:num
                xx = dataB(1:px, ii);
                xx = fft(xx);
                Xx(:, ii) = xx;
            end
            XX = abs(Xx(2:px/2+1, :) * 2 / px).^2;
            f_s = app.HzEditField_2.Value / px;
            xX = XX / (f_s);
            XX = (xX).^0.5;
            xkAx = mean(XX, 2);
            sk2Ax = sum((XX - xkAx).^2, 2) / (num - 1);
            GkAx = (xkAx + (tinv(0.9, (num-1)) / num^0.5 + 2.326 * ((num-1) / chi2inv(0.1, (num-1)))^0.5) * sk2Ax.^0.5).^2;
            for k = 1:px/2 - 1
                FnAx(k) = sk2Ax(k) / sk2Ax(k+1);
                tnAx(k) = (xkAx(k) - xkAx(k+1)) / ((sk2Ax(k) + sk2Ax(k+1)) / num)^0.5;
            end
            LAx = (FnAx <= finv(0.95, (num-1), (num-1))) & (FnAx >= finv(0.05, (num-1), (num-1))) & (abs(tnAx) <= tinv(0.95, 2*(num-1)));
            clear kh1; clear kh2; clear m;
            kh1(1) = 1; kh2(1) = 1; m = 1;
            for i = 1:px/2 - 2
                if (LAx(i) == 0) && (LAx(i+1) == 1)
                    kh1(m) = i + 1;
                end
                if (LAx(i) == 1) && (LAx(i+1) == 0)
                    kh2(m) = i;
                    m = m + 1;
                end
            end
            if length(kh1) > length(kh2)
                kh2(length(kh1)) = px/2 - 1;
            end
            for i = 1:length(kh1)
                Nh(i) = kh2(i) + 1 - kh1(i) + 1;
                xhAx(i) = 1 / (num * Nh(i)) * sum(sum(XX(kh1(i):kh2(i)+1)));
                yAx(i) = 0;
                for j = kh1(i):kh2(i)+1
                    tempAx = sum(((XX(j, :) - xhAx(i)).^2));
                    yAx(i) = yAx(i) + tempAx;
                end
                sh2Ax(i) = 1 / (num * Nh(i) - 1) * yAx(i);
            end
            for i = 1:length(kh1)
                GhAx(i) = (xhAx(i) + (tinv(0.9, (num*Nh(i)-1)) / (num*Nh(i))^0.5 + 2.326 * ((num*Nh(i)-1) / chi2inv(0.1, (num*Nh(i)-1)))^0.5) * sh2Ax(i)^0.5).^2;
            end
            zzAx(1:px/2, 1) = 0.1;
            for i = 1:length(kh1) - 1
                k = log10(GhAx(i+1) / GhAx(i)) / log10(kh1(i+1) / (kh2(i)+1));
                b = log10(GhAx(i)) - log10(kh2(i)+1) * k;
                for j = kh2(i)+1:kh1(i+1)
                    zzAx(j, 1) = 10^(k * log10(j) + b);
                end
            end
            for i = 1:length(kh1)
                for j = kh1(i):kh2(i)+1
                    zzAx(j, 1) = GhAx(i);
                end
            end
            if kh1(1) ~= 1
                k = log10(GhAx(1) / xkAx(1)^2) / log10(kh1(1));
                b = log10(xkAx(1)^2);
                for j = 1:kh1(1)
                    zzAx(j) = 10^(k * log10(j) + b);
                end
            end
            if kh2(length(kh1)) < px/2 - 1
                k = log10(xkAx(px/2-1)^2 / GhAx(length(kh1))) / log10(px/2-1 / kh2(length(kh1))+1);
                b = log10(GhAx(length(kh1))) - log10(kh2(length(kh1))+1) * k;
                for j = kh2(length(kh1))+1:px/2-1
                    zzAx(j) = 10^(k * log10(j) + b);
                end
            end
            f = app.HzEditField_2.Value / px : app.HzEditField_2.Value / px : app.HzEditField_2.Value / 2;
            loglog(app.UIAxes2_2, f, GkAx, '-', 'LineWidth', 1.5, 'Color', [0.00, 0.15, 0.74]);
            hold(app.UIAxes2_2, 'on');
            loglog(app.UIAxes2_2, f, zzAx, '-', 'LineWidth', 1.0, 'Color', [1.00, 0.00, 0.00]);
            for o = 1:num
                loglog(app.UIAxes2_2, f, xX(:, o));
            end
            loglog(app.UIAxes2_2, f, GkAx, '-', 'LineWidth', 1.5, 'Color', [0.00, 0.15, 0.74]);
            loglog(app.UIAxes2_2, f, zzAx, '-', 'LineWidth', 1.0, 'Color', [1.00, 0.00, 0.00]);
            hold(app.UIAxes2_2, 'off');
            drawnow;
            xlim(app.UIAxes2_2, [1, app.HzEditField_2.Value/2]);
            ylim(app.UIAxes2_2, [0.1 * min(GkAx), 5 * max(GkAx)]);
            legend(app.UIAxes2_2, '实测上限谱', '规范谱', 'Location', 'northeast');
            legend(app.UIAxes2_2, 'boxoff');
            grid(app.UIAxes2_2, 'off');
            data = GkAx;
            data(1) = 0;
            data1 = data;
            data2 = data;
            threshold = zeros(size(data));
            threshold(1:end) = 0.01;
            indices = find(data1 > threshold);
            if length(indices) > 0
                starts = indices(diff([0; indices]) > 1);
                ends = indices(diff([indices; numel(data1)]) > 1);
                max_values = zeros(size(starts));
                max_indices = zeros(size(starts));
                for i = 1:numel(starts)
                    [max_values(i), max_index] = max(data(starts(i):ends(i)));
                    max_indices(i) = starts(i) + max_index - 1;
                end
                new_max_indices = max_indices;
                new_max_values = max_values;
                diff_threshold = 0.05;
                to_delete = [];
                for i = 1:numel(max_indices) - 1
                    diff_percent = (max_indices(i+1) - max_indices(i)) / max_indices(i);
                    if diff_percent < diff_threshold
                        [~, ind] = max([max_values(i), max_values(i+1)]);
                        if ind == 1 && i+1 <= numel(new_max_indices)
                            to_delete = [to_delete, i+1];
                        elseif ind == 2 && i <= numel(new_max_indices)
                            to_delete = [to_delete, i];
                        end
                    end
                end
                new_max_indices(to_delete) = [];
                new_max_values(to_delete) = [];
                num1 = length(new_max_indices);
                new_data = zeros(size(data));
                for i = 1:num1
                    center = new_max_indices(i);
                    range = round(0.05 * center);
                    left_range = max(center - range, 1);
                    right_range = min(center + range, numel(data));
                    left_min = min(data(left_range:center));
                    right_min = min(data(center:right_range));
                    left_index = find(data(left_range:center) == left_min, 1, 'last');
                    right_index = find(data(center:right_range) == right_min, 1, 'first');
                    left_index = left_range + left_index - 1;
                    right_index = center + right_index - 1;
                    new_data(left_index:right_index) = mean(data(left_index:right_index));
                    data2(left_index:right_index) = 0.5 * (data(left_index) + data(right_index));
                end
                new_data(new_data == 0) = 0.0000001;
                yy(1:px/2) = 0.01;
                loglog(app.UIAxes2_3, f, yy, '-', 'LineWidth', 1.0, 'Color', [0.00, 1.00, 0.00]);
                hold(app.UIAxes2_3, 'on');
                loglog(app.UIAxes2_3, f, GkAx, '-', 'LineWidth', 1.0, 'Color', [0.00, 0.20, 1.00]);
                loglog(app.UIAxes2_3, f, new_data, '-', 'LineWidth', 1.5, 'Color', [1.00, 0.00, 0.00]);
                hold(app.UIAxes2_3, 'off');
                xlim(app.UIAxes2_3, [1, app.HzEditField_2.Value/2]);
                ylim(app.UIAxes2_3, [0.1*min(GkAx), 5*max(GkAx)]);
                legend(app.UIAxes2_3, 'y=0.01', '上限谱', '窄带分量规范谱', 'Location', 'northeast');
                legend(app.UIAxes2_3, 'boxoff');
                grid(app.UIAxes2_3, 'off');
                d1 = floor(px / app.HzEditField_2.Value);
                d25 = floor(px / app.HzEditField_2.Value * 25);
                d50 = floor(px / app.HzEditField_2.Value * 50);
                d100 = floor(px / app.HzEditField_2.Value * 100);
                pct = 99;
                data3 = data2;
                data3(1:d25) = prctile(data2(d1:d25), pct);
                data3(d25+1:d50) = prctile(data2(d25+1:d50), pct);
                data3(d50+1:d100) = prctile(data2(d50+1:d100), pct);
                data3(d100+1:px/2) = prctile(data2(d100+1:px/2), pct);
                app.Label_7.Text = num2str(data3(d25));
                app.Label_8.Text = num2str(data3(d50));
                app.Label_9.Text = num2str(data3(d100));
                app.Label_10.Text = num2str(data3(d100+1));
                loglog(app.UIAxes2_4, f, data2, '-', 'LineWidth', 1.5, 'Color', [0.00, 0.00, 1.00]);
                hold(app.UIAxes2_4, 'on');
                loglog(app.UIAxes2_4, f, data3, '-', 'LineWidth', 1.5, 'Color', [1.00, 0.00, 0.00]);
                hold(app.UIAxes2_4, 'off');
                xlim(app.UIAxes2_4, [1, app.HzEditField_2.Value/2]);
                ylim(app.UIAxes2_4, [0.1*min(data2), 5*max(data2)]);
                legend(app.UIAxes2_4, '剩余宽带分量', '宽带分量规范谱', 'Location', 'northeast');
                legend(app.UIAxes2_4, 'boxoff');
                grid(app.UIAxes2_4, 'off');
                data4 = max(data3, new_data);
                loglog(app.UIAxes2_5, f, GkAx, '-', 'LineWidth', 1.5, 'Color', [0.00, 0.00, 1.00]);
                hold(app.UIAxes2_5, 'on');
                loglog(app.UIAxes2_5, f, data4, '-', 'LineWidth', 1.5, 'Color', [1.00, 0.00, 0.00]);
                hold(app.UIAxes2_5, 'off');
                xlim(app.UIAxes2_5, [1, app.HzEditField_2.Value/2]);
                ylim(app.UIAxes2_5, [0.1*min(GkAx), 5*max(GkAx)]);
                legend(app.UIAxes2_5, '实测上限谱', '试验谱', 'Location', 'northeast');
                legend(app.UIAxes2_5, 'boxoff');
                grid(app.UIAxes2_5, 'off');
            else
                pct = 99;
                data3 = data;
                d1 = floor(px / app.HzEditField_2.Value);
                d25 = floor(px / app.HzEditField_2.Value * 25);
                d50 = floor(px / app.HzEditField_2.Value * 50);
                d100 = floor(px / app.HzEditField_2.Value * 100);
                data3(1:d25) = prctile(data(d1:d25), pct);
                data3(d25+1:d50) = prctile(data(d25+1:d50), pct);
                data3(d50+1:d100) = prctile(data(d50+1:d100), pct);
                data3(d100+1:px/2) = prctile(data(d100+1:px/2), pct);
                app.Label_7.Text = num2str(data3(d25));
                app.Label_8.Text = num2str(data3(d50));
                app.Label_9.Text = num2str(data3(d100));
                app.Label_10.Text = num2str(data3(d100+1));
                loglog(app.UIAxes2_5, f, GkAx, '-', 'LineWidth', 2.5, 'Color', [0.00, 0.00, 1.00]);
                hold(app.UIAxes2_5, 'on');
                loglog(app.UIAxes2_5, f, data3, '-', 'LineWidth', 2.5, 'Color', [1.00, 0.00, 0.00]);
                hold(app.UIAxes2_5, 'off');
                xlim(app.UIAxes2_5, [1, app.HzEditField_2.Value/2]);
                ylim(app.UIAxes2_5, [0.1*min(GkAx), 5*max(GkAx)]);
                legend(app.UIAxes2_5, '实测上限谱', '试验谱', 'Location', 'northeast');
                legend(app.UIAxes2_5, 'boxoff');
                grid(app.UIAxes2_5, 'off');
            end
        end

        function EditField_4ValueChanged(app, src, event)
        end

        function EditField_5ValueChanged(app, src, event)
        end

        function UIAxes2_3ButtonDown(app, src, event)
        end

        function UIAxes2_4ButtonDown(app, src, event)
        end

        function UIAxes2_5ButtonDown(app, src, event)
        end

        function UIAxes2_6ButtonDown(app, src, event)
        end

        function Button_4Pushed(app, src, event)
            lup = app.EditField_2.Value;
            ldn = app.EditField_3.Value;
            range = sprintf(' A%d:Z%d ', lup, ldn);
            fullFilePath = fullfile(app.EditField.Value);
            data = xlsread(fullFilePath, range);
            i1 = app.iEditField.Value;
            dataC = data(:, i1);
            fd = app.EditField_4.Value;
            dataB = reshape(dataC, fd, (ldn-lup+1)/fd)';
            zd = dataB(:, 1);
            normplot(app.UIAxes2_6, zd);
            title(app.UIAxes2_6, '正态检验-概率图');
            xlabel(app.UIAxes2_6, '数据');
            ylabel(app.UIAxes2_6, '概率');
        end

        function Button_5Pushed(app, src, event)
            lup = app.EditField_2.Value;
            ldn = app.EditField_3.Value;
            range = sprintf(' A%d:Z%d ', lup, ldn);
            fullFilePath = fullfile(app.EditField.Value);
            data = xlsread(fullFilePath, range);
            i1 = app.iEditField.Value;
            dataC = data(:, i1);
            fd = app.EditField_4.Value;
            dataB = reshape(dataC, fd, (ldn-lup+1)/fd)';
            zd = dataB(:, 1);
            autocorr_values = autocorr(zd);
            lag = 0:length(autocorr_values) - 1;
            plot(app.UIAxes2_6, lag, autocorr_values);
            xlabel(app.UIAxes2_6, '延迟');
            ylabel(app.UIAxes2_6, '自相关系数');
            title(app.UIAxes2_6, '稳定检验-自相关函数图');
        end

        function Button_6Pushed(app, src, event)
            N = app.EditField_5.Value;
            Fs = app.HzEditField_2.Value;
            lup = app.EditField_2.Value;
            ldn = app.EditField_3.Value;
            range = sprintf(' A%d:Z%d ', lup, ldn);
            fullFilePath = fullfile(app.EditField.Value);
            data = xlsread(fullFilePath, range);
            i1 = app.iEditField.Value;
            dataC = data(:, i1);
            fd = app.EditField_4.Value;
            dataB = reshape(dataC, fd, (ldn-lup+1)/fd)';
            zd = dataB(:, 1);
            Y = fft(zd);
            P2 = abs(Y/N);
            P1 = P2(1:N/2+1);
            P1(2:end-1) = 2*P1(2:end-1);
            f = Fs*(0:(N/2))/N;
            px = app.EditField_5.Value;
            zq_up = max(P1(floor(px/app.HzEditField_2.Value)+1, end));
            plot(app.UIAxes2_6, f, P1);
            xlim(app.UIAxes2_6, [1, app.HzEditField_2.Value/2]);
            ylim(app.UIAxes2_6, [0, 1.2*max(zq_up)]);
            xlabel(app.UIAxes2_6, '频率/Hz');
            ylabel(app.UIAxes2_6, '振幅');
            title(app.UIAxes2_6, '周期性检验-FFT法');
        end

        function HzEditField_2ValueChanged(app, src, event)
        end

        % ================== Tab_2: 冲击剖面 Callbacks ==================

        function Button_7Pushed(app, src, event)
            [filename, filepath] = uigetfile('*.*', '请选择文件');
            app.EditField_6.Value = [filepath, filename];
        end

        function Button_8Pushed(app, src, event)
            fullFilePath = fullfile(app.EditField_6.Value);
            data = xlsread(fullFilePath);
            i1 = app.iEditField_2.Value;
            n2 = app.HzEditField_3.Value;
            if i1 >= 1 && i1 <= size(data, 2)
                columnData = data(:, i1);
                n1 = length(columnData);
                t1 = 1/n2:1/n2:n1/n2;
                plot(app.UIAxes2_7, t1, columnData);
            else
                errordlg('无效的列号，请输入有效的列号。', '错误', 'modal');
            end
        end

        function Button_9Pushed(app, src, event)
            lup = app.EditField_8.Value;
            ldn = app.EditField_9.Value;
            fullFilePath = fullfile(app.EditField_6.Value);
            data = xlsread(fullFilePath);
            fs = app.HzEditField_3.Value;
            nn = fs / 5;
            dt = 1 / fs;
            i1 = app.iEditField_2.Value;
            in = app.inEditField.Value;
            ln = ldn - lup + 1;
            h1_all = zeros((ldn - lup + 1)/2 + 1, in - i1 + 1);
            freq = 0:fs/ln:fs/2;
            for i = i1:in
                columnData = data(:, i);
                zz1 = columnData(lup:ldn);
                zz12 = fft(zz1);
                amp1 = zz12(1:ln/2+1);
                amp1(2:end-1) = 2 * amp1(2:end-1);
                amp12 = abs(amp1 / nn).^2;
                g2hz1 = (1 / (ln * dt)) * (1 / 9.81^2) * amp12;
                h1 = sqrt(g2hz1 .* freq');
                h1_all(:, i - i1 + 1) = h1;
                loglog(app.UIAxes2_8, freq, h1, '-', 'LineWidth', 0.8, 'DisplayName', sprintf('列%d', i));
                hold(app.UIAxes2_8, 'on');
            end
            max_envelope = max(h1_all, [], 2);
            loglog(app.UIAxes2_8, freq, max_envelope, '-', 'LineWidth', 1.5, 'Color', [1.00, 0.00, 0.00], 'DisplayName', '包络上限');
            xlim(app.UIAxes2_8, [10, fs/2]);
            ylim(app.UIAxes2_8, [0.1 * min(max_envelope), 5 * max(max_envelope)]);
            xlabel(app.UIAxes2_8, '频率/Hz');
            ylabel(app.UIAxes2_8, '冲击相应谱SRS/g');
            hold(app.UIAxes2_8, 'off');
            legend(app.UIAxes2_8, 'show', 'Location', 'northwest');
            pct = 99;
            h2 = max_envelope;
            dataup = h2;
            d10 = floor(ln/fs*10) + 1;
            d2000 = floor(ln/fs*2000) + 1;
            up1 = prctile(h2(d2000:ln/2+1), pct);
            app.Label_15.Text = num2str(up1);
            dataup(d2000:ln/2+1) = up1;
            tzxs = app.EditField_10.Value;
            low1 = h2(d10) * tzxs;
            app.Label_18.Text = num2str(low1);
            k = log10(low1/up1) / log10(d10/d2000);
            b = (log10(up1) - log10(d2000)*k);
            for j = d10:d2000
                dataup(j) = 10^(k*log10(j) + b);
            end
            loglog(app.UIAxes2_9, freq, h2, '-', 'LineWidth', 1.0, 'Color', [0.00, 0.00, 1.00]);
            hold(app.UIAxes2_9, 'on');
            loglog(app.UIAxes2_9, freq, dataup, '-', 'LineWidth', 1.5, 'Color', [1.00, 0.00, 0.00]);
            hold(app.UIAxes2_9, 'off');
            xlim(app.UIAxes2_9, [10, fs/2]);
            ylim(app.UIAxes2_9, [0.01 * min(h2), 10 * max(h2)]);
            legend(app.UIAxes2_9, '冲击实测谱上限', '冲击规范谱', 'Location', 'northwest');
            legend(app.UIAxes2_9, 'boxoff');
            grid(app.UIAxes2_9, 'off');
        end

        function iEditField_2ValueChanged(app, src, event)
        end

        function HzEditField_3ValueChanged(app, src, event)
        end

        function UIAxes2_7ButtonDown(app, src, event)
        end

        function UIAxes2_8ButtonDown(app, src, event)
        end

        function UIAxes2_9ButtonDown(app, src, event)
        end

        function inEditFieldValueChanged(app, src, event)
        end

        function EditField_9ValueChanged(app, src, event)
        end

        function EditField_8ValueChanged(app, src, event)
        end

        function EditField_10ValueChanged(app, src, event)
        end

        function EditField_6ValueChanged(app, src, event)
        end

        % ================== Tab_3: 温湿度剖面1 Callbacks ==================

        function Button_10Pushed(app, src, event)
            [filename, filepath] = uigetfile('*.*', '请选择文件');
            app.EditField_11.Value = [filepath, filename];
        end

        function i1EditFieldValueChanged(app, src, event)
        end

        function i2EditFieldValueChanged(app, src, event)
        end

        function hEditFieldValueChanged(app, src, event)
        end

        function EditField_12ValueChanged(app, src, event)
        end

        function EditField_13ValueChanged(app, src, event)
        end

        function Button_11Pushed(app, src, event)
            fullFilePath = fullfile(app.EditField_11.Value);
            data0 = xlsread(fullFilePath);
            c1 = app.EditField_12.Value;
            c2 = app.hEditField.Value;
            c3 = app.EditField_13.Value;
            l1 = c2 * c3 * 24;
            data = data0(c1:c1+l1-1, :);
            i1 = app.i1EditField.Value;
            i2 = app.i2EditField.Value;
            if i1 >= 1 && i1 <= size(data, 2)
                x1 = data(:, i1);
                s1 = data(:, i2);
                t = c3/(l1):c3/(l1):c3;
                ax1 = app.UIAxes10;
                plot(ax1, t, x1);
                grid(ax1, 'off');
                ax2 = app.UIAxes10_6;
                plot(ax2, t, s1);
                grid(ax2, 'off');
            else
                errordlg('无效的列号，请输入有效的列号。', '错误', 'modal');
            end
            x2 = reshape(x1, c2, 24*c3)';
            s2 = reshape(s1, c2, 24*c3)';
            y1 = x2(:, 1);
            s3 = s2(:, 1);
            y2 = reshape(y1, 24, c3)';
            s4 = reshape(s3, 24, c3)';
            s_means = mean(s4, 2);
            [i1, j1] = meshgrid(1:24, 1:c3);
            ax1 = app.UIAxes10_2;
            surf(ax1, i1, j1, y2);
            xlabel(ax1, '时间/h');
            ylabel(ax1, '时间/d');
            zlabel(ax1, '温度/℃');
            grid(ax1, 'off');
            y3 = y2;
            for j = 1:24
                i = 3;
                while i <= c3 - 2
                    if abs(y2(i, j) - 1/4*(y2(i-2,j)+y2(i-1,j)+y2(i+1,j)+y2(i+2,j))) >= 10
                        y3(i, j) = 1/4*(y2(i-2,j)+y2(i-1,j)+y2(i+1,j)+y2(i+2,j));
                    end
                    i = i + 1;
                end
            end
            y4 = y3;
            for i = 1:c3
                j = 3;
                while j <= 22
                    if abs(y3(i, j-2) - 1/4*(y3(i,j-2)+y3(i,j-1)+y3(i,j+1)+y3(i,j+2))) >= 10
                        y4(i, j) = 1/4*(y3(i,j-2)+y3(i,j-1)+y3(i,j+1)+y3(i,j+2));
                    end
                    j = j + 1;
                end
            end
            y5 = y4;
            for j = 1:24
                i = 2;
                while i <= c3 - 1
                    y5(i, j) = 1/5*(2*y4(i-1,j) + y4(i,j) + 2*y4(i+1,j));
                    i = i + 1;
                end
            end
            y6 = y5;
            ax2 = app.UIAxes10_4;
            surf(ax2, i1, j1, y6);
            xlabel(ax2, '时间/h');
            ylabel(ax2, '时间/d');
            zlabel(ax2, '温度/℃');
            grid(ax2, 'off');
            trendSignals = y6;
            T = trendSignals;
            [numDays, ~] = size(T);
            average_integral_results = zeros(numDays, 1);
            t_values = 1:24;
            for day = 1:numDays
                dailyTemperatureData = T(day, :);
                integral_sum = 0;
                for i = 1:(length(t_values) - 1)
                    t1 = t_values(i);
                    t2 = t_values(i + 1);
                    delta_T = dailyTemperatureData(t2) - dailyTemperatureData(t1);
                    integral_sum = integral_sum + (1 / (dailyTemperatureData(t1)^2)) * delta_T;
                end
                average_integral = integral_sum / (24 - 1);
                average_integral_results(day) = average_integral;
            end
            row_means = mean(T, 2);
            t_sum = row_means + average_integral_results;
            t_year = 1:c3;
            ax3 = app.UIAxes10_7;
            plot(ax3, t_year, t_sum);
            ylabel(ax3, '温度/℃');
            grid(ax3, 'off');
            ax4 = app.UIAxes10_8;
            plot(ax4, t_year, s_means);
            ylabel(ax4, '湿度/%');
            grid(ax4, 'off');
            y7 = reshape(trendSignals', 1, 5064);
            ts = 1:c3*24;
            ax5 = app.UIAxes10_9;
            plot(ax5, ts, y7);
            xlabel(ax5, '时间/h');
            ylabel(ax5, '温度/℃');
            grid(ax5, 'off');
            cutoffFrequency = 1;
            samplingRate = 100;
            filterOrder = 7;
            lpf = designfilt('lowpassfir', 'FilterOrder', filterOrder, 'CutoffFrequency', cutoffFrequency, 'SampleRate', samplingRate);
            filteredData1 = filter(lpf, y7);
            ts = 1:c3*24;
            ax6 = app.UIAxes10_10;
            plot(ax6, ts, filteredData1);
            grid(ax6, 'off');
            y8 = reshape(filteredData1, 24, c3)';
            [i1, j1] = meshgrid(1:24, 1:c3);
            ax7 = app.UIAxes10_12;
            surf(ax7, i1, j1, y8);
            xlabel(ax7, '时间/h');
            ylabel(ax7, '时间/d');
            zlabel(ax7, '温度/℃');
            grid(ax7, 'off');
            hpf = designfilt('highpassfir', 'FilterOrder', filterOrder, 'CutoffFrequency', cutoffFrequency, 'SampleRate', samplingRate);
            filteredData = filter(hpf, y7);
            ax8 = app.UIAxes10_11;
            plot(ax8, ts, filteredData);
            grid(ax8, 'off');
            y9 = reshape(filteredData, 24, 211)';
            [i1, j1] = meshgrid(1:24, 1:c3);
            ax9 = app.UIAxes10_13;
            surf(ax9, i1, j1, y9);
            xlabel(ax9, '时间/h');
            ylabel(ax9, '时间/d');
            zlabel(ax9, '温度/℃');
            grid(ax9, 'off');
            matrix = filteredData;
            peaks = islocalmax(matrix);
            valleys = islocalmin(matrix);
            peak_values = matrix(peaks);
            valley_values = matrix(valleys);
            sorted_peak_values = sort(peak_values, 'descend');
            sorted_valley_values = sort(valley_values);
            if length(sorted_peak_values) >= 2
                second_largest_peak = sorted_peak_values(2);
            else
                second_largest_peak = NaN;
            end
            if length(sorted_valley_values) >= 2
                second_smallest_valley = sorted_valley_values(2);
            else
                second_smallest_valley = NaN;
            end
            lff = 0.5 * (second_largest_peak - second_smallest_valley);
            segmentSize = 24;
            cycleCount = 0;
            for i = 1:segmentSize:length(filteredData)-segmentSize+1
                segmentData = filteredData(i:i+segmentSize-1);
                maxVal = max(segmentData);
                minVal = min(segmentData);
                if maxVal - minVal >= lff
                    cycleCount = cycleCount + 1;
                end
            end
            above_20 = t_sum(t_sum >= 20);
            below_20 = t_sum(t_sum < 20);
            count_above_20 = length(above_20);
            average_above_20 = mean(above_20);
            count_below_20 = length(below_20);
            average_below_20 = mean(below_20);
            app.Label_22.Text = num2str(count_above_20);
            app.Label_24.Text = num2str(average_above_20);
            app.Label_33.Text = num2str(average_above_20);
            app.Label_26.Text = num2str(count_below_20);
            app.Label_28.Text = num2str(average_below_20);
            app.Label_34.Text = num2str(average_below_20);
            above_20_indices = find(t_sum >= 20);
            corresponding_s_means = s_means(above_20_indices);
            average_s_means_above_20 = mean(corresponding_s_means);
            app.Label_30.Text = num2str(average_s_means_above_20);
            app.Label_36.Text = ['湿度' num2str(average_s_means_above_20) '%'];
            tc = average_above_20 - average_below_20;
            b = log(5 / tc) / log(cycleCount / c3);
            n2 = cycleCount * (5 / tc)^(1/b);
            result = ceil(n2);
            app.Label_32.Text = num2str(result);
            app.Label_38.Text = ['共' num2str(result) '个循环'];
            app.Label_37.Text = '-----';
            psy = [10 10 10 25 25 25 10];
            psx = 1:7;
            ax10 = app.UIAxes10_14;
            plot(ax10, psx, psy);
            xlim(ax10, [1, 10]);
            ylim(ax10, [0, 30]);
            xticks(ax10, [0]);
            yticks(ax10, [0]);
            grid(ax10, 'off');
            ul = round(count_above_20 / result);
            app.Label_43.Text = [num2str(ul) '天'];
            u2 = round(count_below_20 / result);
            app.Label_44.Text = [num2str(u2) '天'];
        end

        function UIAxes10ButtonDown(app, src, event)
        end

        function UIAxes10_6ButtonDown(app, src, event)
        end

        function UIAxes10_2ButtonDown(app, src, event)
        end

        % ================== Tab_5: 倾角剖面 Callbacks ==================

        function Button_12Pushed(app, src, event)
            [filename, filepath] = uigetfile('*.*', '请选择文件');
            app.EditField_14.Value = [filepath, filename];
        end

        function EditField_14ValueChanged(app, src, event)
        end

        function xi1EditFieldValueChanged(app, src, event)
        end

        function yi2EditFieldValueChanged(app, src, event)
        end

        function zi3EditFieldValueChanged(app, src, event)
        end

        function EditField_15ValueChanged(app, src, event)
        end

        function EditField_16ValueChanged(app, src, event)
        end

        function fsEditFieldValueChanged(app, src, event)
        end

        function xButtonPushed(app, src, event)
            fullFilePath = fullfile(app.EditField_14.Value);
            lup = app.EditField_15.Value;
            ldn = app.EditField_16.Value;
            lie1 = app.xi1EditField.Value;
            long = ldn - lup + 1;
            range = sprintf(' A%d:Z%d ', lup, ldn);
            A0 = xlsread(fullFilePath, range);
            fs = app.fsEditField.Value;
            Ax = A0(:, lie1);
            ax = app.UIAxes10_15;
            t = 1/fs:1/fs:long/fs;
            plot(ax, t, Ax);
            grid(ax, 'off');
            A = Ax;
            [maxima, maxima_indices] = findpeaks(A);
            [minima, minima_indices] = findpeaks(-A);
            extrema_indices = sort(vertcat(maxima_indices, minima_indices));
            differences = diff(A(extrema_indices));
            time_differences = diff(extrema_indices) / fs;
            [max_difference, max_difference_index] = max(abs(differences));
            corresponding_time_difference = time_differences(max_difference_index);
            T1 = 4 * corresponding_time_difference;
            app.Label_47.Text = num2str(max_difference);
            app.Label_50.Text = num2str(T1);
            ax1 = app.UIAxes10_16;
            scatter(ax1, time_differences, abs(differences), 'o', 'filled');
            grid(ax1, 'off');
            ax2 = app.UIAxes10_21;
            t1 = 0:1/8*corresponding_time_difference:4*corresponding_time_difference;
            ys = max_difference * sin(t1*pi/corresponding_time_difference/2);
            plot(ax2, t1, ys);
            grid(ax2, 'off');
        end

        function yButtonPushed(app, src, event)
            fullFilePath = fullfile(app.EditField_14.Value);
            lie2 = app.yi2EditField.Value;
            lup = app.EditField_15.Value;
            ldn = app.EditField_16.Value;
            long = ldn - lup + 1;
            range = sprintf(' A%d:Z%d ', lup, ldn);
            A0 = xlsread(fullFilePath, range);
            fs = app.fsEditField.Value;
            Ax = A0(:, lie2);
            ax = app.UIAxes10_17;
            t = 1/fs:1/fs:long/fs;
            plot(ax, t, Ax);
            grid(ax, 'off');
            A = Ax;
            [maxima, maxima_indices] = findpeaks(A);
            [minima, minima_indices] = findpeaks(-A);
            extrema_indices = sort(vertcat(maxima_indices, minima_indices));
            differences = diff(A(extrema_indices));
            time_differences = diff(extrema_indices) / fs;
            [max_difference, max_difference_index] = max(abs(differences));
            corresponding_time_difference = time_differences(max_difference_index);
            T1 = 4 * corresponding_time_difference;
            app.Label_52.Text = num2str(max_difference);
            app.Label_53.Text = num2str(T1);
            ax1 = app.UIAxes10_18;
            scatter(ax1, time_differences, abs(differences), 'o', 'filled');
            grid(ax1, 'off');
            ax2 = app.UIAxes10_22;
            t1 = 0:1/8*corresponding_time_difference:4*corresponding_time_difference;
            ys = max_difference * sin(t1*pi/corresponding_time_difference/2);
            plot(ax2, t1, ys);
            grid(ax2, 'off');
        end

        function zButtonPushed(app, src, event)
            lie3 = app.zi3EditField.Value;
            lup = app.EditField_15.Value;
            ldn = app.EditField_16.Value;
            long = ldn - lup + 1;
            fullFilePath = fullfile(app.EditField_14.Value);
            range = sprintf(' A%d:Z%d ', lup, ldn);
            A0 = xlsread(fullFilePath, range);
            fs = app.fsEditField.Value;
            Ax = A0(:, lie3);
            ax = app.UIAxes10_19;
            t = 1/fs:1/fs:long/fs;
            plot(ax, t, Ax);
            grid(ax, 'off');
            A = Ax;
            [maxima, maxima_indices] = findpeaks(A);
            [minima, minima_indices] = findpeaks(-A);
            extrema_indices = sort(vertcat(maxima_indices, minima_indices));
            differences = diff(A(extrema_indices));
            time_differences = diff(extrema_indices) / fs;
            [max_difference, max_difference_index] = max(abs(differences));
            corresponding_time_difference = time_differences(max_difference_index);
            T1 = 4 * corresponding_time_difference;
            app.Label_55.Text = num2str(max_difference);
            app.Label_56.Text = num2str(T1);
            ax1 = app.UIAxes10_20;
            scatter(ax1, time_differences, abs(differences), 'o', 'filled');
            grid(ax1, 'off');
            ax2 = app.UIAxes10_23;
            t1 = 0:1/8*corresponding_time_difference:4*corresponding_time_difference;
            ys = max_difference * sin(t1*pi/corresponding_time_difference/2);
            plot(ax2, t1, ys);
            grid(ax2, 'off');
        end

        function UIAxes10_15ButtonDown(app, src, event)
        end

        function UIAxes10_16ButtonDown(app, src, event)
        end

        function UIAxes10_21ButtonDown(app, src, event)
        end

        function UIAxes10_17ButtonDown(app, src, event)
        end

        function UIAxes10_18ButtonDown(app, src, event)
        end

        function UIAxes10_22ButtonDown(app, src, event)
        end

        function UIAxes10_19ButtonDown(app, src, event)
        end

        function UIAxes10_20ButtonDown(app, src, event)
        end

        function UIAxes10_23ButtonDown(app, src, event)
        end

    end
    % ================================================================
    % CALLBACKS - Tab_6: 设备应力综合分析 (NEW V2.0)
    % ================================================================
    methods (Access = private)

        % --- 文件选择 ---
        function Button_17Pushed(app, src, event)
            app.curTabIdx = 1;
            [filename, filepath] = uigetfile({'*.xlsx;*.xls;*.csv;*.txt', '数据文件 (*.xlsx,*.xls,*.csv,*.txt)'}, '请选择数据文件');
            if isequal(filename, 0), return; end
            app.EditField_17.Value = fullfile(filepath, filename);
            app.Label_66.Text = ['已选择文件: ' filename];
        end

        function Button_18Pushed(app, src, event)
            app.curTabIdx = 1;
            app.tabc_doAnalyze('蒸汽压力', 'MPa');
        end

        function Button_25Pushed(app, src, event), end
        function Button_19Pushed(app, src, event)
            app.curTabIdx = 1; app.tabc_export();
        end
        function Button_20Pushed(app, src, event)
            app.curTabIdx = 1; app.tabc_refreshCharts();
        end
        function ListBox_1ValueChanged(app, src, event)
            app.curTabIdx = 1; app.tabc_refreshCharts();
        end
        function EditField_18ValueChanged(app, src, event)
            app.curTabIdx = 1; app.tabc_refreshCharts();
        end
        function EditField_19ValueChanged(app, src, event)
            app.curTabIdx = 1; app.tabc_refreshCharts();
        end

        % --- Tab_7 回调 ---
        function Button_26Pushed(app, src, event)
            app.curTabIdx = 2;
            [filename, filepath] = uigetfile({'*.xlsx;*.xls;*.csv;*.txt', '数据文件 (*.xlsx,*.xls,*.csv,*.txt)'}, '请选择数据文件');
            if isequal(filename, 0), return; end
            app.EditField_20.Value = fullfile(filepath, filename);
            app.Label_71.Text = ['已选择文件: ' filename];
        end
        function Button_27Pushed(app, src, event)
            app.curTabIdx = 2; app.tabc_doAnalyze('蒸汽流量', 'm3/h');
        end
        function Button_28Pushed(app, src, event), app.curTabIdx = 2; app.tabc_export(); end
        function Button_29Pushed(app, src, event), app.curTabIdx = 2; app.tabc_refreshCharts(); end
        function ListBox_2ValueChanged(app, src, event), app.curTabIdx = 2; app.tabc_refreshCharts(); end
        function EditField_28ValueChanged(app, src, event), app.curTabIdx = 2; app.tabc_refreshCharts(); end
        function EditField_29ValueChanged(app, src, event), app.curTabIdx = 2; app.tabc_refreshCharts(); end

        % --- Tab_8 回调 ---
        function Button_31Pushed(app, src, event)
            app.curTabIdx = 3;
            [filename, filepath] = uigetfile({'*.xlsx;*.xls;*.csv;*.txt', '数据文件 (*.xlsx,*.xls,*.csv,*.txt)'}, '请选择数据文件');
            if isequal(filename, 0), return; end
            app.EditField_21.Value = fullfile(filepath, filename);
            app.Label_211.Text = ['已选择文件: ' filename];
        end
        function Button_32Pushed(app, src, event)
            app.curTabIdx = 3; app.tabc_doAnalyze('蒸汽颗粒物浓度', '%');
        end
        function Button_33Pushed(app, src, event), app.curTabIdx = 3; app.tabc_export(); end
        function Button_34Pushed(app, src, event), app.curTabIdx = 3; app.tabc_refreshCharts(); end
        function ListBox_3ValueChanged(app, src, event), app.curTabIdx = 3; app.tabc_refreshCharts(); end
        function EditField_31ValueChanged(app, src, event), app.curTabIdx = 3; app.tabc_refreshCharts(); end
        function EditField_32ValueChanged(app, src, event), app.curTabIdx = 3; app.tabc_refreshCharts(); end

        % --- Tab_9 回调 ---
        function Button_36Pushed(app, src, event)
            app.curTabIdx = 4;
            [filename, filepath] = uigetfile({'*.xlsx;*.xls;*.csv;*.txt', '数据文件 (*.xlsx,*.xls,*.csv,*.txt)'}, '请选择数据文件');
            if isequal(filename, 0), return; end
            app.EditField_22.Value = fullfile(filepath, filename);
            app.Label_219.Text = ['已选择文件: ' filename];
        end
        function Button_37Pushed(app, src, event)
            app.curTabIdx = 4; app.tabc_doAnalyze('盐雾浓度', 'mg/m3');
        end
        function Button_38Pushed(app, src, event), app.curTabIdx = 4; app.tabc_export(); end
        function Button_39Pushed(app, src, event), app.curTabIdx = 4; app.tabc_refreshCharts(); end
        function ListBox_4ValueChanged(app, src, event), app.curTabIdx = 4; app.tabc_refreshCharts(); end
        function EditField_33ValueChanged(app, src, event), app.curTabIdx = 4; app.tabc_refreshCharts(); end
        function EditField_34ValueChanged(app, src, event), app.curTabIdx = 4; app.tabc_refreshCharts(); end

        % --- Tab_10 回调 ---
        function Button_41Pushed(app, src, event)
            app.curTabIdx = 5;
            [filename, filepath] = uigetfile({'*.xlsx;*.xls;*.csv;*.txt', '数据文件 (*.xlsx,*.xls,*.csv,*.txt)'}, '请选择数据文件');
            if isequal(filename, 0), return; end
            app.EditField_23.Value = fullfile(filepath, filename);
            app.Label_226.Text = ['已选择文件: ' filename];
        end
        function Button_42Pushed(app, src, event)
            app.curTabIdx = 5; app.tabc_doAnalyze('氧浓度', '%');
        end
        function Button_43Pushed(app, src, event), app.curTabIdx = 5; app.tabc_export(); end
        function Button_44Pushed(app, src, event), app.curTabIdx = 5; app.tabc_refreshCharts(); end
        function ListBox_5ValueChanged(app, src, event), app.curTabIdx = 5; app.tabc_refreshCharts(); end
        function EditField_35ValueChanged(app, src, event), app.curTabIdx = 5; app.tabc_refreshCharts(); end
        function EditField_36ValueChanged(app, src, event), app.curTabIdx = 5; app.tabc_refreshCharts(); end
    end

    % ================================================================
    % HELPER METHODS - Tab_6~10 (Generic)
    % ================================================================
    methods (Access = private)

        % ========== 获取当前Tab的控件句柄 ==========
        function c = getTabCtrls(app)
            switch app.curTabIdx
                case 1, c.edPath=app.EditField_17; c.listbox=app.ListBox_1; c.table=app.UITable_2; c.axLine=app.UIAxes_24; c.axBox=app.UIAxes_25; c.edYmin=app.EditField_18; c.edYmax=app.EditField_19; c.lblCur=app.Label_62; c.lblCnt=app.Label_63; c.lblTypes=app.Label_64; c.lblStatus=app.Label_66;
                case 2, c.edPath=app.EditField_20; c.listbox=app.ListBox_2; c.table=app.UITable_3; c.axLine=app.UIAxes_26; c.axBox=app.UIAxes_27; c.edYmin=app.EditField_28; c.edYmax=app.EditField_29; c.lblCur=app.Label_68; c.lblCnt=app.Label_69; c.lblTypes=app.Label_70; c.lblStatus=app.Label_71;
                case 3, c.edPath=app.EditField_21; c.listbox=app.ListBox_3; c.table=app.UITable_4; c.axLine=app.UIAxes_28; c.axBox=app.UIAxes_29; c.edYmin=app.EditField_31; c.edYmax=app.EditField_32; c.lblCur=app.Label_208; c.lblCnt=app.Label_209; c.lblTypes=app.Label_210; c.lblStatus=app.Label_211;
                case 4, c.edPath=app.EditField_22; c.listbox=app.ListBox_4; c.table=app.UITable_5; c.axLine=app.UIAxes_30; c.axBox=app.UIAxes_31; c.edYmin=app.EditField_33; c.edYmax=app.EditField_34; c.lblCur=app.Label_216; c.lblCnt=app.Label_217; c.lblTypes=app.Label_218; c.lblStatus=app.Label_219;
                case 5, c.edPath=app.EditField_23; c.listbox=app.ListBox_5; c.table=app.UITable_6; c.axLine=app.UIAxes_32; c.axBox=app.UIAxes_33; c.edYmin=app.EditField_35; c.edYmax=app.EditField_36; c.lblCur=app.Label_223_t10; c.lblCnt=app.Label_224; c.lblTypes=app.Label_225; c.lblStatus=app.Label_226;
            end
        end

        % ========== 核心分析函数 ==========
        function tabc_doAnalyze(app, paramName, paramUnit)
            c = getTabCtrls(app);
            try
                filePath = strtrim(c.edPath.Value);
                if isempty(filePath)
                    errordlg('请先选择数据文件！', '错误', 'modal');
                    return;
                end
                if ~isfile(filePath)
                    errordlg(['文件不存在: ' filePath], '错误', 'modal');
                    return;
                end

                % L1-E03: 文件被占用检测
                [fid, errmsg] = fopen(filePath, 'r');
                if fid == -1
                    errordlg(['文件无法打开: ' errmsg], '错误', 'modal');
                    return;
                end
                fclose(fid);

                % L2: 检查扩展名
                [~, ~, ext] = fileparts(filePath);
                supportedExts = {'.xlsx', '.xls', '.csv', '.txt'};
                if ~any(strcmpi(ext, supportedExts))
                    errordlg(['不支持的文件格式 "' ext '"，请使用 .xlsx / .xls / .csv / .txt 格式。'], '错误', 'modal');
                    return;
                end

                % L2: 读取文件
                try
                    opts = detectImportOptions(filePath);
                    opts.VariableNamesLine = 1;
                    opts.VariableNamingRule = 'preserve';
                    T = readtable(filePath, opts);
                catch ME
                    errordlg(['文件读取失败，请检查文件是否损坏或编码格式有误。' newline ME.message], '错误', 'modal');
                    return;
                end

                % L2-E06: 空文件检查
                if isempty(T) || height(T) == 0
                    errordlg('文件为空，无有效数据。', '错误', 'modal');
                    return;
                end

                % L3-E07: 列数检查
                nCols = width(T);
                if nCols < 2
                    errordlg(['数据列数不足(当前' num2str(nCols) '列)，需要至少2列：{设备标签, 数值}。'], '错误', 'modal');
                    return;
                end

                % L3: 解析三列数据
                rawTags = string(T{:, 1});
                rawValues = T{:, 2};
                rawUnits = strings(height(T), 1);
                if nCols >= 3
                    rawUnits = string(T{:, 3});
                end

                % L3-E10: 空标签处理
                emptyTagIdx = strlength(strtrim(rawTags)) == 0 | ismissing(rawTags);
                if any(emptyTagIdx)
                    rawTags(emptyTagIdx) = '未命名';
                    c.lblStatus.Text = ['注意: ' num2str(sum(emptyTagIdx)) ' 条数据的标签为空，已标记为"未命名"'];
                end

                % L3-E08/E09: 数值列检查
                if iscell(rawValues)
                    numValues = str2double(rawValues);
                else
                    numValues = double(rawValues);
                end
                nanCount = sum(isnan(numValues));
                if nanCount == length(numValues)
                    errordlg('数值列全部无效，请检查数据文件第2列是否为数字格式。', '错误', 'modal');
                    return;
                end
                if nanCount > 0
                    c.lblStatus.Text = [c.lblStatus.Text ' | 跳过 ' num2str(nanCount) ' 条无效数值'];
                end

                % L4: 单位筛选
                validIdx = ~isnan(numValues);
                if nCols >= 3 && ~all(strlength(strtrim(rawUnits)) == 0)
                    validIdx = validIdx & contains(rawUnits, paramUnit, 'IgnoreCase', true);
                    if sum(validIdx) == 0
                        answer = questdlg(['文件中没有找到单位"' paramUnit '"的数据，是否使用全部数据进行分析？'], ...
                            '单位不匹配', '使用全部数据', '取消', '使用全部数据');
                        if strcmp(answer, '取消')
                            return;
                        end
                        validIdx = ~isnan(numValues);
                    end
                end

                % L4-E14: 筛选后无数据
                allTags = cellstr(rawTags(validIdx));
                allValues = numValues(validIdx);
                allUnits = cellstr(rawUnits(validIdx));
                if isempty(allValues)
                    errordlg('筛选后无有效数据，请检查数据内容。', '错误', 'modal');
                    return;
                end

                % L5: 分组统计
                [uniqueTags, ~, ic] = unique(allTags, 'stable');
                nDevices = length(uniqueTags);

                % L5-E18: 设备种类过多
                if nDevices > 50
                    answer = questdlg(['检测到 ' num2str(nDevices) ' 种设备，数量较多，是否继续分析？'], ...
                        '设备种类确认', '继续', '取消', '继续');
                    if strcmp(answer, '取消')
                        return;
                    end
                end

                % L6: 6项统计计算
                nDev = length(uniqueTags);
                statData = zeros(nDev, 6);
                for d = 1:nDev
                    v = allValues(ic == d);
                    v = v(~isnan(v));
                    if isempty(v)
                        statData(d, :) = NaN;
                    else
                        statData(d, 1) = max(v);
                        statData(d, 2) = min(v);
                        statData(d, 3) = mean(v);
                        try
                            statData(d, 4) = rms(v);
                        catch
                            statData(d, 4) = sqrt(mean(v.^2));
                        end
                        if length(v) >= 2
                            statData(d, 5) = var(v);
                            statData(d, 6) = std(v);
                        else
                            statData(d, 5) = NaN;
                            statData(d, 6) = NaN;
                        end
                    end
                end

                % L7: 更新状态
                app.TabState(app.curTabIdx).Loaded = true;
                app.TabState(app.curTabIdx).Param = paramName;
                app.TabState(app.curTabIdx).Unit = paramUnit;
                app.TabState(app.curTabIdx).File = filePath;
                app.TabState(app.curTabIdx).Tags = allTags;
                app.TabState(app.curTabIdx).Values = allValues;
                app.TabState(app.curTabIdx).Units = allUnits;
                app.TabState(app.curTabIdx).CatNames = uniqueTags;


                c.listbox.Multiselect = 'on';
                c.listbox.Items = cellstr(uniqueTags);
                c.listbox.Value = cellstr(uniqueTags);

                c.table.Data = statData;
                c.table.ColumnName = {'最大值', '最小值', '平均值', '均方根值', '方差', '标准差'};
                c.table.RowName = cellstr(uniqueTags);

                c.lblCur.Text = ['当前模块: ' paramName ' (' paramUnit ')'];
                c.lblCnt.Text = ['数据条数: ' num2str(length(allValues))];
                c.lblTypes.Text = ['设备类型数: ' num2str(nDevices)];

                dataRange = max(allValues) - min(allValues);
                if dataRange == 0, dataRange = 1; end
                ymin = round(min(allValues) - 0.1 * dataRange, 3);
                ymax = round(max(allValues) + 0.1 * dataRange, 3);
                c.edYmin.Value = ymin;
                c.edYmax.Value = ymax;

                app.tabc_refreshCharts();
                c.lblStatus.Text = ['分析完成: ' paramName ' | ' num2str(length(allValues)) '条数据, ' num2str(nDevices) '种设备'];
            catch ME
                % E99: 全局异常兜底
                errordlg(['系统错误: ' ME.message newline '请检查数据格式或联系管理员。'], '错误', 'modal');
                disp(['[E99] tab6_doAnalyze 异常: ' ME.message]);
                disp(['堆栈: ' ME.stack(1).name ' line ' num2str(ME.stack(1).line)]);
                c.lblStatus.Text = '分析失败，请检查数据格式';
            end
        end

        % ========== 图表刷新函数: tab6_refreshCharts ==========
        function tabc_refreshCharts(app)
            if ~app.TabState(app.curTabIdx).Loaded, return; end
            if isempty(app.TabState(app.curTabIdx).Values), return; end

            c = getTabCtrls(app);
            selectedDevices = c.listbox.Value;
            if isempty(selectedDevices), return; end
            if ischar(selectedDevices), selectedDevices = {selectedDevices}; end

            % Y轴范围
            ymin = c.edYmin.Value;
            ymax = c.edYmax.Value;
            if ymin >= ymax
                allVals = app.TabState(app.curTabIdx).Values(~isnan(app.TabState(app.curTabIdx).Values));
                dataRange = max(allVals) - min(allVals);
                if dataRange == 0, dataRange = 1; end
                ymin = round(min(allVals) - 0.1 * dataRange, 3);
                ymax = round(max(allVals) + 0.1 * dataRange, 3);
                c.edYmin.Value = ymin;
                c.edYmax.Value = ymax;
            end

            % ---- 折线图 ----
            cla(c.axLine);
            legendEntries = {};
            hold(c.axLine, 'on');
            colors = lines(length(selectedDevices));
            for d = 1:length(selectedDevices)
                devName = selectedDevices{d};
                idx = strcmp(app.TabState(app.curTabIdx).Tags, devName);
                vals = app.TabState(app.curTabIdx).Values(idx);
                vals = vals(~isnan(vals));
                if isempty(vals), continue; end
                n = length(vals);
                x = 1:n;
                if n <= 50
                    plot(c.axLine, x, vals, '-o', 'LineWidth', 1.5, 'Color', colors(d, :), 'MarkerSize', 4, 'DisplayName', devName);
                elseif n <= 200
                    plot(c.axLine, x, vals, '-.', 'LineWidth', 1.0, 'Color', colors(d, :), 'MarkerSize', 2, 'DisplayName', devName);
                else
                    plot(c.axLine, x, vals, '-', 'LineWidth', 0.8, 'Color', colors(d, :), 'DisplayName', devName);
                end
                legendEntries{end+1} = devName;
            end
            hold(c.axLine, 'off');
            title(c.axLine, ['设备应力时序对比 - ' app.TabState(app.curTabIdx).Param]);
            xlabel(c.axLine, '测量序号');
            ylabel(c.axLine, ['数值 (' app.TabState(app.curTabIdx).Unit ')']);
            ylim(c.axLine, [ymin, ymax]);
            if ~isempty(legendEntries)
                lg = legend(c.axLine, legendEntries, 'Location', 'northeast');
                set(lg, 'Box', 'on', 'EdgeColor', [0.4 0.4 0.4], 'LineWidth', 1);
            end
            grid(c.axLine, 'on');

            % ---- 箱线图 ----
            cla(c.axBox);
            boxData = {}; boxLabels = {};
            for d = 1:length(selectedDevices)
                devName = selectedDevices{d};
                idx = strcmp(app.TabState(app.curTabIdx).Tags, devName);
                vals = app.TabState(app.curTabIdx).Values(idx);
                vals = vals(~isnan(vals));
                if length(vals) < 3, continue; end
                boxData{end+1} = vals(:);
                boxLabels{end+1} = devName;
            end
            if ~isempty(boxData)
                try
                    boxplot(c.axBox, boxData, 'Labels', boxLabels, 'Symbol', 'x');
                catch
                    cla(c.axBox); hold(c.axBox, 'on');
                    for k = 1:length(boxData)
                        v = boxData{k}; q = prctile(v, [25 50 75]);
                        x0 = k - 0.2; x1 = k + 0.2;
                        fill(c.axBox, [x0 x1 x1 x0], [q(1) q(1) q(3) q(3)], [0.7 0.85 1], 'EdgeColor', [0 0.3 0.6], 'LineWidth', 1.2);
                        plot(c.axBox, [x0 x1], [q(2) q(2)], 'r-', 'LineWidth', 1.5);
                        iqr = q(3) - q(1);
                        wlo = max(min(v), q(1) - 1.5*iqr); whi = min(max(v), q(3) + 1.5*iqr);
                        plot(c.axBox, [k k], [q(1) wlo], 'k-', 'LineWidth', 0.8);
                        plot(c.axBox, [k k], [q(3) whi], 'k-', 'LineWidth', 0.8);
                        plot(c.axBox, [k-0.1 k+0.1], [wlo wlo], 'k-', 'LineWidth', 0.8);
                        plot(c.axBox, [k-0.1 k+0.1], [whi whi], 'k-', 'LineWidth', 0.8);
                        out_lo = v(v < q(1) - 1.5*iqr); out_hi = v(v > q(3) + 1.5*iqr);
                        outliers = [out_lo(:); out_hi(:)];
                        if ~isempty(outliers)
                            plot(c.axBox, k*ones(size(outliers)), outliers, 'rx', 'MarkerSize', 5, 'LineWidth', 1.2);
                        end
                    end
                    hold(c.axBox, 'off');
                    set(c.axBox, 'XTick', 1:length(boxLabels), 'XTickLabel', boxLabels);
                end
                title(c.axBox, ['应力分布分析 - ' app.TabState(app.curTabIdx).Param]);
                ylabel(c.axBox, ['数值 (' app.TabState(app.curTabIdx).Unit ')']);
                ylim(c.axBox, [ymin, ymax]);
                grid(c.axBox, 'on');
            end
        end

        % ========== 导出函数: tab6_export ==========
        function tabc_export(app)
            c = getTabCtrls(app);
            if ~app.TabState(app.curTabIdx).Loaded
                errordlg('没有可导出的图表，请先加载数据。', '提示', 'modal');
                return;
            end
            [filename, filepath, filterIdx] = uiputfile({'*.png', 'PNG图片 (*.png)'; '*.fig', 'MATLAB图形 (*.fig)'}, '导出图表');
            if isequal(filename, 0)
                return;
            end
            fullExportPath = fullfile(filepath, filename);
            try
                if filterIdx == 1
                    % PNG导出
                    exportgraphics(c.axLine, fullExportPath, 'Resolution', 300);
                    msgbox(['折线图已导出为: ' fullExportPath], '导出成功');
                elseif filterIdx == 2
                    % FIG导出
                    fig = figure('Visible', 'off');
                    axCopy = copyobj(c.axLine, fig);
                    set(axCopy, 'Units', 'normalized', 'Position', [0.13 0.11 0.775 0.815]);
                    savefig(fig, fullExportPath);
                    close(fig);
                    msgbox(['折线图已导出为: ' fullExportPath], '导出成功');
                end
            catch ME
                errordlg(['导出失败: ' ME.message], '错误', 'modal');
            end
        end

        % ========== 设备对比函数: tab6_doCompare (数学建模优化) ==========
        function tabc_doCompare(app)
            c = getTabCtrls(app);
            if ~app.TabState(app.curTabIdx).Loaded
                errordlg('请先加载数据再对比。', '提示', 'modal');
                return;
            end

            selectedDevices = c.listbox.Value;
            if isempty(selectedDevices)
                errordlg('请先在左侧列表中选择要对比的设备。', '提示', 'modal');
                return;
            end
            if ischar(selectedDevices)
                selectedDevices = {selectedDevices};
            end
            if length(selectedDevices) < 2
                errordlg('请至少选择2个设备进行对比。', '提示', 'modal');
                return;
            end

            statNames = {'最大值', '最小值', '平均值', 'RMS', '方差', '标准差'};
            nSel = length(selectedDevices);
            compData = zeros(nSel, 6);

            for d = 1:nSel
                idx = strcmp(app.TabState(app.curTabIdx).Tags, selectedDevices{d});
                v = app.TabState(app.curTabIdx).Values(idx);
                v = v(~isnan(v));
                if isempty(v)
                    compData(d, :) = NaN;
                else
                    compData(d, 1) = max(v);
                    compData(d, 2) = min(v);
                    compData(d, 3) = mean(v);
                    try
                        compData(d, 4) = rms(v);
                    catch
                        compData(d, 4) = sqrt(mean(v.^2));
                    end
                    if length(v) >= 2
                        compData(d, 5) = var(v);
                        compData(d, 6) = std(v);
                    else
                        compData(d, 5) = NaN;
                        compData(d, 6) = NaN;
                    end
                end
            end

            % ==================== 数学建模: TOPSIS综合评分 ====================
            % 1) 正向化: 方差/std越小越稳定(逆向), 其余越大越好(正向)
            X = compData;
            % 排除全NaN行
            validRows = ~all(isnan(X), 2);
            X_valid = X(validRows, :);
            nValid = size(X_valid, 1);

            % 正向化: 列5=方差,列6=标准差 -> 取负号转为正向
            X_pos = X_valid;
            X_pos(:, 5) = -X_valid(:, 5);  % 方差越小越好
            X_pos(:, 6) = -X_valid(:, 6);  % 标准差越小越好

            % 2) 标准化 (向量归一化)
            X_norm = zeros(size(X_pos));
            for j = 1:6
                col = X_pos(:, j);
                if all(~isnan(col)) && norm(col) > 0
                    X_norm(:, j) = col / norm(col);
                end
            end

            % 3) 信息熵权重: 熵越大(信息越少)→权重越小
            P = X_norm;
            P(P < 0) = 0;
            P = P ./ max(sum(P, 1), eps);
            k = 1 / log(max(nValid, 2));
            E = zeros(1, 6);
            for j = 1:6
                pj = P(:, j);
                pj(pj == 0) = eps;
                E(j) = -k * sum(pj .* log(pj));
            end
            W = (1 - E) / max(sum(1 - E), eps);  % 熵权法权重

            % 4) TOPSIS: 正理想解D+ 和 负理想解D-
            X_weighted = X_norm .* W;
            Dplus = zeros(nValid, 1);
            Dminus = zeros(nValid, 1);
            for i = 1:nValid
                Dplus(i) = sqrt(sum((X_weighted(i, :) - max(X_weighted, [], 1)).^2, 'omitnan'));
                Dminus(i) = sqrt(sum((X_weighted(i, :) - min(X_weighted, [], 1)).^2, 'omitnan'));
            end
            C = Dminus ./ (Dplus + Dminus + eps);  % 相对贴近度, 越大越优
            [~, bestIdx] = max(C);
            bestDevice = selectedDevices{bestIdx};

            % ==================== UIAxes_24: 分组柱状图(6项并排) ====================
            cla(c.axLine);
            b = bar(c.axLine, compData, 'grouped');
            title(c.axLine, ['设备对比柱状图 - ' app.TabState(app.curTabIdx).Param ' (' app.TabState(app.curTabIdx).Unit ') | 最优: ' bestDevice]);
            xlabel(c.axLine, '设备');
            ylabel(c.axLine, ['数值 (' app.TabState(app.curTabIdx).Unit ')']);
            set(c.axLine, 'XTickLabel', selectedDevices);
            legend(c.axLine, statNames, 'Location', 'bestoutside');
            legend(c.axLine, 'boxoff');
            grid(c.axLine, 'on');
            colors6 = lines(6);
            for i = 1:6
                b(i).FaceColor = colors6(i, :);
            end
            % 数值标注(RMS值)
            for i = 1:nSel
                yVal = compData(i, 4);
                if ~isnan(yVal)
                    text(c.axLine, i - 0.28, yVal + 0.02 * max(compData(:), [], 'omitnan'), ...
                        sprintf('%.3f', yVal), 'FontSize', 7, 'Color', [0 0 0], 'FontWeight', 'bold');
                end
            end
            % 最优设备标注
            text(c.axLine, bestIdx, max(compData(bestIdx, :)) * 1.05, ...
                ['★最优: ' bestDevice], 'FontSize', 10, 'Color', [1 0 0], ...
                'FontWeight', 'bold', 'HorizontalAlignment', 'center');

            % ==================== UIAxes_25: 箱线图对比(原始数据) ====================
            cla(c.axBox);
            boxData = {};
            boxLabels = {};
            for d = 1:nSel
                idx = strcmp(app.TabState(app.curTabIdx).Tags, selectedDevices{d});
                v = app.TabState(app.curTabIdx).Values(idx);
                v = v(~isnan(v));
                if length(v) >= 3
                    boxData{end+1} = v;
                    boxLabels{end+1} = selectedDevices{d};
                end
            end
            if ~isempty(boxData)
                bx = boxplot(c.axBox, boxData, 'Labels', boxLabels, 'Symbol', 'x');
                title(c.axBox, ['分布对比 - ' app.TabState(app.curTabIdx).Param ' (' app.TabState(app.curTabIdx).Unit ') | 权重: ' ...
                    sprintf('%.2f ', W)]);
                ylabel(c.axBox, ['数值 (' app.TabState(app.curTabIdx).Unit ')']);
                grid(c.axBox, 'on');
                % 高亮最优设备箱体
                for bb = 1:length(bx)
                    set(bx(bb, :), 'LineWidth', 1);
                end
                if bestIdx <= size(bx, 2)
                    set(bx(:, bestIdx), 'LineWidth', 2, 'Color', [1 0 0]);
                end
            end

            % ==================== 更新状态栏 ====================
            [~, sortIdx] = sort(C, 'descend');
            rankStr = '';
            for r = 1:length(sortIdx)
                rankStr = [rankStr sprintf('%d.%s(C=%.3f) ', r, selectedDevices{sortIdx(r)}, C(sortIdx(r)))];
            end
            c.lblStatus.Text = ['设备排名: ' rankStr '| 参数: ' app.TabState(app.curTabIdx).Param];
        end

    end
    % ================================================================
    % COMPONENT INITIALIZATION - createComponents
    % ================================================================
    methods (Access = private)

        function createComponents(app)

            if isdeployed
                imgPath = ctfroot;
            else
                imgPath = '.';
            end

            % --- Figure ---
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Color = [1 1 1];
            app.UIFigure.Position = [0 0 1280 720];
            app.UIFigure.Name = 'MATLAB App';
            app.UIFigure.Icon = fullfile(imgPath, 'boatt.png');

            % --- TabGroup ---
            app.TabGroup = uitabgroup(app.UIFigure);
            app.TabGroup.Position = [1 1 1280 720];

            % ===========================================
            % Tab_1: 振动剖面
            % ===========================================
            app.Tab = uitab(app.TabGroup);
            app.Tab.Title = '振动剖面';
            app.Tab.BackgroundColor = [1 1 1];
            app.Tab.ForegroundColor = [0 0.4471 0.7412];

            app.Button = uibutton(app.Tab, 'push');
            app.Button.ButtonPushedFcn = @(src, evt) app.ButtonPushed(src, evt);
            app.Button.BackgroundColor = [0.0588 1 1];
            app.Button.Position = [42 612 88 24];
            app.Button.Text = '选择数据';

            app.EditField = uieditfield(app.Tab, 'text');
            app.EditField.Position = [137 613 100 22];

            app.iLabel = uilabel(app.Tab);
            app.iLabel.HorizontalAlignment = 'right';
            app.iLabel.Position = [51 585 71 22];
            app.iLabel.Text = '文件所在列/ i ';

            app.iEditField = uieditfield(app.Tab, 'numeric');
            app.iEditField.ValueChangedFcn = @(src, evt) app.iEditFieldValueChanged2(src, evt);
            app.iEditField.Position = [137 585 100 22];

            app.Button_2 = uibutton(app.Tab, 'push');
            app.Button_2.ButtonPushedFcn = @(src, evt) app.Button_2Pushed2(src, evt);
            app.Button_2.BackgroundColor = [0.0588 1 1];
            app.Button_2.Position = [42 526 88 24];
            app.Button_2.Text = '画时域图';

            app.HzEditField_2Label = uilabel(app.Tab);
            app.HzEditField_2Label.HorizontalAlignment = 'right';
            app.HzEditField_2Label.Position = [51 555 71 22];
            app.HzEditField_2Label.Text = '采样频率/Hz';

            app.HzEditField_2 = uieditfield(app.Tab, 'numeric');
            app.HzEditField_2.ValueChangedFcn = @(src, evt) app.HzEditField_2ValueChanged(src, evt);
            app.HzEditField_2.Position = [137 555 100 22];

            app.Label = uilabel(app.Tab);
            app.Label.HorizontalAlignment = 'right';
            app.Label.Position = [295 585 53 22];
            app.Label.Text = '数据初值';

            app.EditField_2 = uieditfield(app.Tab, 'numeric');
            app.EditField_2.ValueChangedFcn = @(src, evt) app.EditField_2ValueChanged(src, evt);
            app.EditField_2.Position = [363 585 100 22];

            app.Label_2 = uilabel(app.Tab);
            app.Label_2.HorizontalAlignment = 'right';
            app.Label_2.Position = [295 555 53 22];
            app.Label_2.Text = '数据末值';

            app.EditField_3 = uieditfield(app.Tab, 'numeric');
            app.EditField_3.ValueChangedFcn = @(src, evt) app.EditField_3ValueChanged(src, evt);
            app.EditField_3.Position = [363 555 100 22];

            app.Label_3 = uilabel(app.Tab);
            app.Label_3.Position = [298 613 161 22];
            app.Label_3.Text = '频域分析选择的原始数据范围';

            app.Button_3 = uibutton(app.Tab, 'push');
            app.Button_3.ButtonPushedFcn = @(src, evt) app.Button_3Pushed(src, evt);
            app.Button_3.BackgroundColor = [0 1 1];
            app.Button_3.Position = [297 526 100 24];
            app.Button_3.Text = '上限图&规范谱';

            app.Button_4 = uibutton(app.Tab, 'push');
            app.Button_4.ButtonPushedFcn = @(src, evt) app.Button_4Pushed(src, evt);
            app.Button_4.BackgroundColor = [0 1 1];
            app.Button_4.Position = [707 612 100 24];
            app.Button_4.Text = '正态性检验';

            app.Button_5 = uibutton(app.Tab, 'push');
            app.Button_5.ButtonPushedFcn = @(src, evt) app.Button_5Pushed(src, evt);
            app.Button_5.BackgroundColor = [0 1 1];
            app.Button_5.Position = [707 580 100 24];
            app.Button_5.Text = '稳定性检验';

            app.Button_6 = uibutton(app.Tab, 'push');
            app.Button_6.ButtonPushedFcn = @(src, evt) app.Button_6Pushed(src, evt);
            app.Button_6.BackgroundColor = [0 1 1];
            app.Button_6.Position = [707 547 100 24];
            app.Button_6.Text = '周期性检验';

            app.Label_4 = uilabel(app.Tab);
            app.Label_4.Position = [730 644 53 22];
            app.Label_4.Text = '前期检验';

            app.Label_5 = uilabel(app.Tab);
            app.Label_5.HorizontalAlignment = 'right';
            app.Label_5.Position = [505 585 48 22];
            app.Label_5.Text = '分 段 数';

            app.EditField_4 = uieditfield(app.Tab, 'numeric');
            app.EditField_4.ValueChangedFcn = @(src, evt) app.EditField_4ValueChanged(src, evt);
            app.EditField_4.Position = [568 585 100 22];

            app.Label_6 = uilabel(app.Tab);
            app.Label_6.HorizontalAlignment = 'right';
            app.Label_6.Position = [505 557 48 22];
            app.Label_6.Text = '谱 线 数';

            app.EditField_5 = uieditfield(app.Tab, 'numeric');
            app.EditField_5.ValueChangedFcn = @(src, evt) app.EditField_5ValueChanged(src, evt);
            app.EditField_5.Position = [568 557 100 22];

            app.Label_7 = uilabel(app.Tab);
            app.Label_7.BackgroundColor = [0.8824 0.9804 0.9804];
            app.Label_7.HorizontalAlignment = 'center';
            app.Label_7.Position = [837 555 89 22];
            app.Label_7.Text = '';

            app.HzLabel = uilabel(app.Tab);
            app.HzLabel.HorizontalAlignment = 'center';
            app.HzLabel.Position = [850 586 64 22];
            app.HzLabel.Text = '1-25Hz';

            app.Label_8 = uilabel(app.Tab);
            app.Label_8.BackgroundColor = [0.8824 0.9804 0.9804];
            app.Label_8.HorizontalAlignment = 'center';
            app.Label_8.Position = [941 555 89 22];
            app.Label_8.Text = '';

            app.HzLabel_2 = uilabel(app.Tab);
            app.HzLabel_2.HorizontalAlignment = 'center';
            app.HzLabel_2.Position = [944 586 71 22];
            app.HzLabel_2.Text = '25-50Hz';

            app.Label_9 = uilabel(app.Tab);
            app.Label_9.BackgroundColor = [0.8824 0.9804 0.9804];
            app.Label_9.HorizontalAlignment = 'center';
            app.Label_9.Position = [1045 555 89 22];
            app.Label_9.Text = '';

            app.HzLabel_3 = uilabel(app.Tab);
            app.HzLabel_3.HorizontalAlignment = 'center';
            app.HzLabel_3.Position = [1045 586 78 22];
            app.HzLabel_3.Text = '50-100Hz';

            app.Label_10 = uilabel(app.Tab);
            app.Label_10.BackgroundColor = [0.8824 0.9804 0.9804];
            app.Label_10.HorizontalAlignment = 'center';
            app.Label_10.Position = [1149 555 89 22];
            app.Label_10.Text = '';

            app.HzLabel_4 = uilabel(app.Tab);
            app.HzLabel_4.HorizontalAlignment = 'center';
            app.HzLabel_4.Position = [1152 586 84 22];
            app.HzLabel_4.Text = '大于100Hz';

            app.ms22HzLabel = uilabel(app.Tab);
            app.ms22HzLabel.Position = [981 619 174 22];
            app.ms22HzLabel.Text = '宽带功率谱密度值/(m/s^2)^2/Hz';

            app.Label_42 = uilabel(app.Tab);
            app.Label_42.FontSize = 24;
            app.Label_42.FontColor = [0.1333 0.4392 0.6392];
            app.Label_42.Position = [60 640 198 31];
            app.Label_42.Text = '振动剖面生成模块';

            app.Image = uiimage(app.Tab);
            app.Image.Position = [1 633 43 43];
            app.Image.ImageSource = fullfile(imgPath, 'boatt.png');

            app.UIAxes2 = uiaxes(app.Tab);
            title(app.UIAxes2, '时域图');
            xlabel(app.UIAxes2, '时间/s');
            ylabel(app.UIAxes2, '加速度/m/s^2');
            app.UIAxes2.Position = [60 269 366 249];

            app.UIAxes2_2 = uiaxes(app.Tab);
            title(app.UIAxes2_2, '正态单侧上限-频域图');
            xlabel(app.UIAxes2_2, '频率/Hz');
            ylabel(app.UIAxes2_2, '功率谱密度(m/s^2)^2/Hz');
            app.UIAxes2_2.Position = [451 269 366 249];

            app.UIAxes2_3 = uiaxes(app.Tab);
            title(app.UIAxes2_3, '窄带规范谱-频域图');
            xlabel(app.UIAxes2_3, '频率/Hz');
            ylabel(app.UIAxes2_3, '功率谱密度(m/s^2)^2/Hz');
            app.UIAxes2_3.Position = [60 13 366 249];

            app.UIAxes2_4 = uiaxes(app.Tab);
            title(app.UIAxes2_4, '宽带规范谱-频域图');
            xlabel(app.UIAxes2_4, '频率/Hz');
            ylabel(app.UIAxes2_4, '功率谱密度(m/s^2)^2/Hz');
            app.UIAxes2_4.Position = [451 13 366 249];

            app.UIAxes2_5 = uiaxes(app.Tab);
            title(app.UIAxes2_5, '总规范谱-频域图');
            xlabel(app.UIAxes2_5, '频率/Hz');
            ylabel(app.UIAxes2_5, '功率谱密度(m/s^2)^2/Hz');
            app.UIAxes2_5.Position = [841 13 366 249];

            app.UIAxes2_6 = uiaxes(app.Tab);
            title(app.UIAxes2_6, '前期检验图');
            xlabel(app.UIAxes2_6, '因变量');
            ylabel(app.UIAxes2_6, '相关影响系数');
            app.UIAxes2_6.Position = [841 269 366 249];

            % ===========================================
            % Tab_2: 冲击剖面
            % ===========================================
            app.Tab_2 = uitab(app.TabGroup);
            app.Tab_2.Title = '冲击剖面';
            app.Tab_2.BackgroundColor = [1 1 1];
            app.Tab_2.ForegroundColor = [0 0.4471 0.7412];

            app.Button_7 = uibutton(app.Tab_2, 'push');
            app.Button_7.ButtonPushedFcn = @(src, evt) app.Button_7Pushed(src, evt);
            app.Button_7.BackgroundColor = [0.0588 1 1];
            app.Button_7.Position = [59 593 88 24];
            app.Button_7.Text = '选择数据';

            app.EditField_6 = uieditfield(app.Tab_2, 'text');
            app.EditField_6.Position = [154 595 100 22];

            app.Button_8 = uibutton(app.Tab_2, 'push');
            app.Button_8.ButtonPushedFcn = @(src, evt) app.Button_8Pushed(src, evt);
            app.Button_8.BackgroundColor = [0.0588 1 1];
            app.Button_8.Position = [59 460 80 24];
            app.Button_8.Text = '画时域图';

            app.Label_11 = uilabel(app.Tab_2);
            app.Label_11.Position = [273 594 161 22];
            app.Label_11.Text = '频域分析选择的原始数据范围';

            app.Button_9 = uibutton(app.Tab_2, 'push');
            app.Button_9.ButtonPushedFcn = @(src, evt) app.Button_9Pushed(src, evt);
            app.Button_9.BackgroundColor = [0 1 1];
            app.Button_9.Position = [277 460 100 24];
            app.Button_9.Text = '上限图&规范谱';

            app.iEditField_2Label = uilabel(app.Tab_2);
            app.iEditField_2Label.Position = [68 563 71 22];
            app.iEditField_2Label.Text = '文件所在列/ i ';

            app.iEditField_2 = uieditfield(app.Tab_2, 'numeric');
            app.iEditField_2.ValueChangedFcn = @(src, evt) app.iEditField_2ValueChanged(src, evt);
            app.iEditField_2.Position = [154 563 100 22];

            app.HzEditField_3Label = uilabel(app.Tab_2);
            app.HzEditField_3Label.Position = [68 531 71 22];
            app.HzEditField_3Label.Text = '采样频率/Hz';

            app.HzEditField_3 = uieditfield(app.Tab_2, 'numeric');
            app.HzEditField_3.ValueChangedFcn = @(src, evt) app.HzEditField_3ValueChanged(src, evt);
            app.HzEditField_3.Position = [154 531 100 22];

            app.Label_12 = uilabel(app.Tab_2);
            app.Label_12.HorizontalAlignment = 'right';
            app.Label_12.Position = [270 530 53 22];
            app.Label_12.Text = '数据末值';

            app.EditField_9 = uieditfield(app.Tab_2, 'numeric');
            app.EditField_9.Position = [338 530 100 22];

            app.Label_13 = uilabel(app.Tab_2);
            app.Label_13.HorizontalAlignment = 'right';
            app.Label_13.Position = [270 563 53 22];
            app.Label_13.Text = '数据初值';

            app.EditField_8 = uieditfield(app.Tab_2, 'numeric');
            app.EditField_8.Position = [338 563 100 22];

            app.inEditFieldLabel = uilabel(app.Tab_2);
            app.inEditFieldLabel.Position = [68 498 71 22];
            app.inEditFieldLabel.Text = '截止列/in';

            app.inEditField = uieditfield(app.Tab_2, 'numeric');
            app.inEditField.Position = [154 498 100 22];

            app.Label_14 = uilabel(app.Tab_2);
            app.Label_14.Position = [461 563 65 22];
            app.Label_14.Text = '平直段数值';

            app.Label_15 = uilabel(app.Tab_2);
            app.Label_15.BackgroundColor = [0.8 0.9882 0.9882];
            app.Label_15.HorizontalAlignment = 'right';
            app.Label_15.Position = [528 563 96 22];
            app.Label_15.Text = '';

            app.Label_16 = uilabel(app.Tab_2);
            app.Label_16.HorizontalAlignment = 'right';
            app.Label_16.Position = [270 497 53 22];
            app.Label_16.Text = '调整系数';

            app.EditField_10 = uieditfield(app.Tab_2, 'numeric');
            app.EditField_10.Position = [338 497 100 22];

            app.HzLabel_5 = uilabel(app.Tab_2);
            app.HzLabel_5.Position = [468 530 58 22];
            app.HzLabel_5.Text = '10Hz数值';

            app.Label_18 = uilabel(app.Tab_2);
            app.Label_18.BackgroundColor = [0.8 0.9882 0.9882];
            app.Label_18.HorizontalAlignment = 'right';
            app.Label_18.Position = [528 530 96 22];
            app.Label_18.Text = '';

            app.SRSgLabel = uilabel(app.Tab_2);
            app.SRSgLabel.Position = [496 592 93 22];
            app.SRSgLabel.Text = '规范谱值SRS(g)';

            app.Label_41 = uilabel(app.Tab_2);
            app.Label_41.FontSize = 24;
            app.Label_41.FontColor = [0.1333 0.4392 0.6392];
            app.Label_41.Position = [60 639 198 31];
            app.Label_41.Text = '冲击剖面生成模块';

            app.Image_2 = uiimage(app.Tab_2);
            app.Image_2.Position = [1 633 43 43];
            app.Image_2.ImageSource = fullfile(imgPath, 'boatt.png');

            app.UIAxes2_7 = uiaxes(app.Tab_2);
            title(app.UIAxes2_7, '时域图');
            xlabel(app.UIAxes2_7, '时间/s');
            ylabel(app.UIAxes2_7, '加速度/m/s^2');
            app.UIAxes2_7.Position = [51 34 572 316];

            app.UIAxes2_8 = uiaxes(app.Tab_2);
            title(app.UIAxes2_8, '正态单侧上限/包络-频域图');
            xlabel(app.UIAxes2_8, '频率/Hz');
            ylabel(app.UIAxes2_8, '冲击相应谱SRS(g)');
            app.UIAxes2_8.Position = [653 364 572 316];

            app.UIAxes2_9 = uiaxes(app.Tab_2);
            title(app.UIAxes2_9, '试验谱');
            xlabel(app.UIAxes2_9, '频率/Hz');
            ylabel(app.UIAxes2_9, '冲击相应谱SRS(g)');
            app.UIAxes2_9.Position = [653 34 572 316];

            % ===========================================
            % Tab_3: 温湿度剖面1
            % ===========================================
            app.Tab_3 = uitab(app.TabGroup);
            app.Tab_3.Title = '温湿度剖面1';
            app.Tab_3.BackgroundColor = [1 1 1];
            app.Tab_3.ForegroundColor = [0 0.4471 0.7412];

            app.Button_10 = uibutton(app.Tab_3, 'push');
            app.Button_10.ButtonPushedFcn = @(src, evt) app.Button_10Pushed(src, evt);
            app.Button_10.BackgroundColor = [0.0588 1 1];
            app.Button_10.Position = [59 590 88 24];
            app.Button_10.Text = '选择数据';

            app.EditField_11 = uieditfield(app.Tab_3, 'text');
            app.EditField_11.Position = [154 592 100 22];

            app.i1EditFieldLabel = uilabel(app.Tab_3);
            app.i1EditFieldLabel.HorizontalAlignment = 'right';
            app.i1EditFieldLabel.Position = [61 559 78 22];
            app.i1EditFieldLabel.Text = '湿度所在列/i1';

            app.i1EditField = uieditfield(app.Tab_3, 'numeric');
            app.i1EditField.ValueChangedFcn = @(src, evt) app.i1EditFieldValueChanged(src, evt);
            app.i1EditField.Position = [154 559 100 22];

            app.Button_11 = uibutton(app.Tab_3, 'push');
            app.Button_11.ButtonPushedFcn = @(src, evt) app.Button_11Pushed(src, evt);
            app.Button_11.BackgroundColor = [0.0588 1 1];
            app.Button_11.Position = [60 492 88 24];
            app.Button_11.Text = '剖面计算';

            app.i2EditFieldLabel = uilabel(app.Tab_3);
            app.i2EditFieldLabel.HorizontalAlignment = 'right';
            app.i2EditFieldLabel.Position = [61 525 78 22];
            app.i2EditFieldLabel.Text = '温度所在列/i2';

            app.i2EditField = uieditfield(app.Tab_3, 'numeric');
            app.i2EditField.ValueChangedFcn = @(src, evt) app.i2EditFieldValueChanged(src, evt);
            app.i2EditField.Position = [154 525 100 22];

            app.hEditFieldLabel = uilabel(app.Tab_3);
            app.hEditFieldLabel.HorizontalAlignment = 'right';
            app.hEditFieldLabel.Position = [263 559 60 22];
            app.hEditFieldLabel.Text = '每h采样数';

            app.hEditField = uieditfield(app.Tab_3, 'numeric');
            app.hEditField.ValueChangedFcn = @(src, evt) app.hEditFieldValueChanged(src, evt);
            app.hEditField.Position = [331 559 107 22];

            app.EditField_12Label = uilabel(app.Tab_3);
            app.EditField_12Label.HorizontalAlignment = 'right';
            app.EditField_12Label.Position = [263 592 53 22];
            app.EditField_12Label.Text = '数据初值';

            app.EditField_12 = uieditfield(app.Tab_3, 'numeric');
            app.EditField_12.ValueChangedFcn = @(src, evt) app.EditField_12ValueChanged(src, evt);
            app.EditField_12.Position = [331 592 107 22];

            app.EditField_13Label = uilabel(app.Tab_3);
            app.EditField_13Label.HorizontalAlignment = 'right';
            app.EditField_13Label.Position = [263 525 53 22];
            app.EditField_13Label.Text = '样本天数';

            app.EditField_13 = uieditfield(app.Tab_3, 'numeric');
            app.EditField_13.ValueChangedFcn = @(src, evt) app.EditField_13ValueChanged(src, evt);
            app.EditField_13.Position = [331 525 107 22];

            app.Label_39 = uilabel(app.Tab_3);
            app.Label_39.FontSize = 24;
            app.Label_39.FontColor = [0.1333 0.4392 0.6392];
            app.Label_39.Position = [60 639 222 31];
            app.Label_39.Text = '温湿度前期处理部分';

            app.Image_3 = uiimage(app.Tab_3);
            app.Image_3.Position = [1 633 43 43];
            app.Image_3.ImageSource = fullfile(imgPath, 'boatt.png');

            app.UIAxes10 = uiaxes(app.Tab_3);
            title(app.UIAxes10, '温度原始数据');
            xlabel(app.UIAxes10, '时间/天');
            ylabel(app.UIAxes10, '温度/℃');
            app.UIAxes10.Position = [62 252 390 216];

            app.UIAxes10_2 = uiaxes(app.Tab_3);
            title(app.UIAxes10_2, '温度原始数据');
            app.UIAxes10_2.Position = [462 366 390 300];

            app.UIAxes10_4 = uiaxes(app.Tab_3);
            title(app.UIAxes10_4, '温度前期处理后');
            app.UIAxes10_4.Position = [462 13 390 300];

            app.UIAxes10_6 = uiaxes(app.Tab_3);
            title(app.UIAxes10_6, '湿度原始数据');
            xlabel(app.UIAxes10_6, '时间/天');
            ylabel(app.UIAxes10_6, '湿度/%');
            app.UIAxes10_6.Position = [62 13 390 216];

            app.UIAxes10_7 = uiaxes(app.Tab_3);
            title(app.UIAxes10_7, '温度疲劳损伤等效后每天平均结果');
            xlabel(app.UIAxes10_7, '时间/天');
            ylabel(app.UIAxes10_7, '温度/℃');
            app.UIAxes10_7.Position = [867 467 390 216];

            app.UIAxes10_8 = uiaxes(app.Tab_3);
            title(app.UIAxes10_8, '湿度每天平均结果');
            xlabel(app.UIAxes10_8, '时间/天');
            ylabel(app.UIAxes10_8, '湿度/%');
            app.UIAxes10_8.Position = [867 240 390 216];

            app.UIAxes10_9 = uiaxes(app.Tab_3);
            title(app.UIAxes10_9, '温度处理后再展开数据');
            xlabel(app.UIAxes10_9, '时间/h');
            ylabel(app.UIAxes10_9, '湿度/%');
            app.UIAxes10_9.Position = [867 13 390 216];

            % ===========================================
            % Tab_4: 温湿度剖面2
            % ===========================================
            app.Tab_4 = uitab(app.TabGroup);
            app.Tab_4.Title = '温湿度剖面2';
            app.Tab_4.BackgroundColor = [1 1 1];
            app.Tab_4.ForegroundColor = [0 0.4471 0.7412];

            app.Label_20 = uilabel(app.Tab_4);
            app.Label_20.Position = [58 575 53 22];
            app.Label_20.Text = '循环次数';

            app.Label_19 = uilabel(app.Tab_4);
            app.Label_19.BackgroundColor = [0.8 0.9882 0.9882];
            app.Label_19.HorizontalAlignment = 'right';
            app.Label_19.Position = [123 575 96 22];
            app.Label_19.Text = '';

            app.Label_21 = uilabel(app.Tab_4);
            app.Label_21.Position = [58 536 61 22];
            app.Label_21.Text = '≥20℃天数';

            app.Label_22 = uilabel(app.Tab_4);
            app.Label_22.BackgroundColor = [0.8 0.9882 0.9882];
            app.Label_22.HorizontalAlignment = 'right';
            app.Label_22.Position = [123 536 96 22];
            app.Label_22.Text = '';

            app.Label_23 = uilabel(app.Tab_4);
            app.Label_23.Position = [241 536 53 22];
            app.Label_23.Text = '平均高温';

            app.Label_24 = uilabel(app.Tab_4);
            app.Label_24.BackgroundColor = [0.8 0.9882 0.9882];
            app.Label_24.HorizontalAlignment = 'right';
            app.Label_24.Position = [330 536 96 22];
            app.Label_24.Text = '';

            app.Label_25 = uilabel(app.Tab_4);
            app.Label_25.Position = [58 498 62 22];
            app.Label_25.Text = '<20℃天数';

            app.Label_26 = uilabel(app.Tab_4);
            app.Label_26.BackgroundColor = [0.8 0.9882 0.9882];
            app.Label_26.HorizontalAlignment = 'right';
            app.Label_26.Position = [123 498 96 22];
            app.Label_26.Text = '';

            app.Label_27 = uilabel(app.Tab_4);
            app.Label_27.Position = [241 498 53 22];
            app.Label_27.Text = '平均低温';

            app.Label_28 = uilabel(app.Tab_4);
            app.Label_28.BackgroundColor = [0.8 0.9882 0.9882];
            app.Label_28.HorizontalAlignment = 'right';
            app.Label_28.Position = [330 498 96 22];
            app.Label_28.Text = '';

            app.Label_29 = uilabel(app.Tab_4);
            app.Label_29.Position = [241 460 89 22];
            app.Label_29.Text = '高温天平均湿度';

            app.Label_30 = uilabel(app.Tab_4);
            app.Label_30.BackgroundColor = [0.8 0.9882 0.9882];
            app.Label_30.HorizontalAlignment = 'right';
            app.Label_30.Position = [330 460 96 22];
            app.Label_30.Text = '';

            app.Label_31 = uilabel(app.Tab_4);
            app.Label_31.Position = [241 575 77 22];
            app.Label_31.Text = '等效循环次数';

            app.Label_32 = uilabel(app.Tab_4);
            app.Label_32.BackgroundColor = [0.8 0.9882 0.9882];
            app.Label_32.HorizontalAlignment = 'right';
            app.Label_32.Position = [330 575 96 22];
            app.Label_32.Text = '';

            app.Label_33 = uilabel(app.Tab_4);
            app.Label_33.Position = [32 243 55 22];
            app.Label_33.Text = '';

            app.Label_34 = uilabel(app.Tab_4);
            app.Label_34.Position = [32 109 55 22];
            app.Label_34.Text = '';

            app.Label_36 = uilabel(app.Tab_4);
            app.Label_36.Position = [187 252 112 22];
            app.Label_36.Text = '';

            app.Label_37 = uilabel(app.Tab_4);
            app.Label_37.HorizontalAlignment = 'center';
            app.Label_37.FontSize = 20;
            app.Label_37.FontWeight = 'bold';
            app.Label_37.Position = [345 180 93 24];
            app.Label_37.Text = '';

            app.Label_38 = uilabel(app.Tab_4);
            app.Label_38.HorizontalAlignment = 'center';
            app.Label_38.Position = [345 152 93 22];
            app.Label_38.Text = '';

            app.Label_40 = uilabel(app.Tab_4);
            app.Label_40.FontSize = 24;
            app.Label_40.FontColor = [0.1333 0.4392 0.6392];
            app.Label_40.Position = [60 639 222 31];
            app.Label_40.Text = '温湿度剖面生成部分';

            app.Image_4 = uiimage(app.Tab_4);
            app.Image_4.Position = [1 633 43 43];
            app.Image_4.ImageSource = fullfile(imgPath, 'boatt.png');

            app.Label_43 = uilabel(app.Tab_4);
            app.Label_43.HorizontalAlignment = 'center';
            app.Label_43.Position = [205 209 77 22];
            app.Label_43.Text = '';

            app.Label_44 = uilabel(app.Tab_4);
            app.Label_44.Position = [107 88 112 22];
            app.Label_44.Text = '';

            app.UIAxes10_10 = uiaxes(app.Tab_4);
            title(app.UIAxes10_10, '温度低频部分');
            xlabel(app.UIAxes10_10, '时间/h');
            ylabel(app.UIAxes10_10, '温度/℃');
            app.UIAxes10_10.Position = [462 366 390 300];

            app.UIAxes10_11 = uiaxes(app.Tab_4);
            title(app.UIAxes10_11, '温度高频部分');
            xlabel(app.UIAxes10_11, '时间/h');
            ylabel(app.UIAxes10_11, '温度/℃');
            app.UIAxes10_11.Position = [462 13 390 300];

            app.UIAxes10_12 = uiaxes(app.Tab_4);
            title(app.UIAxes10_12, '温度低频部分');
            xlabel(app.UIAxes10_12, '时间/h');
            ylabel(app.UIAxes10_12, '温度/℃');
            app.UIAxes10_12.Position = [873 367 390 300];

            app.UIAxes10_13 = uiaxes(app.Tab_4);
            title(app.UIAxes10_13, '温度高频部分');
            xlabel(app.UIAxes10_13, '时间/h');
            ylabel(app.UIAxes10_13, '温度/℃');
            app.UIAxes10_13.Position = [873 14 390 300];

            app.UIAxes10_14 = uiaxes(app.Tab_4);
            title(app.UIAxes10_14, '温度剖面示意图');
            xlabel(app.UIAxes10_14, '时间/天');
            ylabel(app.UIAxes10_14, '温度/℃');
            app.UIAxes10_14.Position = [48 13 390 300];

            % ===========================================
            % Tab_5: 倾角剖面
            % ===========================================
            app.Tab_5 = uitab(app.TabGroup);
            app.Tab_5.Title = '倾角剖面';
            app.Tab_5.BackgroundColor = [1 1 1];
            app.Tab_5.ForegroundColor = [0 0.4471 0.7412];

            app.Button_12 = uibutton(app.Tab_5, 'push');
            app.Button_12.ButtonPushedFcn = @(src, evt) app.Button_12Pushed(src, evt);
            app.Button_12.BackgroundColor = [0.0588 1 1];
            app.Button_12.Position = [48 590 88 24];
            app.Button_12.Text = '选择数据';

            app.EditField_14 = uieditfield(app.Tab_5, 'text');
            app.EditField_14.Position = [154 591 100 22];

            app.xButton = uibutton(app.Tab_5, 'push');
            app.xButton.ButtonPushedFcn = @(src, evt) app.xButtonPushed(src, evt);
            app.xButton.BackgroundColor = [0.0588 1 1];
            app.xButton.Position = [48 344 88 24];
            app.xButton.Text = 'x轴计算';

            app.xi1Label = uilabel(app.Tab_5);
            app.xi1Label.HorizontalAlignment = 'right';
            app.xi1Label.Position = [50 556 84 22];
            app.xi1Label.Text = '倾角x轴列数/i1';

            app.xi1EditField = uieditfield(app.Tab_5, 'numeric');
            app.xi1EditField.ValueChangedFcn = @(src, evt) app.xi1EditFieldValueChanged(src, evt);
            app.xi1EditField.Position = [154 556 100 22];

            app.yi2EditFieldLabel = uilabel(app.Tab_5);
            app.yi2EditFieldLabel.HorizontalAlignment = 'right';
            app.yi2EditFieldLabel.Position = [50 522 84 22];
            app.yi2EditFieldLabel.Text = '倾角y轴列数/i2';

            app.yi2EditField = uieditfield(app.Tab_5, 'numeric');
            app.yi2EditField.ValueChangedFcn = @(src, evt) app.yi2EditFieldValueChanged(src, evt);
            app.yi2EditField.Position = [154 522 100 22];

            app.zi3EditFieldLabel = uilabel(app.Tab_5);
            app.zi3EditFieldLabel.HorizontalAlignment = 'right';
            app.zi3EditFieldLabel.Position = [50 488 84 22];
            app.zi3EditFieldLabel.Text = '倾角z轴列数/i3';

            app.zi3EditField = uieditfield(app.Tab_5, 'numeric');
            app.zi3EditField.ValueChangedFcn = @(src, evt) app.zi3EditFieldValueChanged(src, evt);
            app.zi3EditField.Position = [154 488 100 22];

            app.EditField_15Label = uilabel(app.Tab_5);
            app.EditField_15Label.HorizontalAlignment = 'right';
            app.EditField_15Label.Position = [66 454 53 22];
            app.EditField_15Label.Text = '数据初值';

            app.EditField_15 = uieditfield(app.Tab_5, 'numeric');
            app.EditField_15.ValueChangedFcn = @(src, evt) app.EditField_15ValueChanged(src, evt);
            app.EditField_15.Position = [154 454 100 22];

            app.fsEditFieldLabel = uilabel(app.Tab_5);
            app.fsEditFieldLabel.HorizontalAlignment = 'right';
            app.fsEditFieldLabel.Position = [67 388 51 22];
            app.fsEditFieldLabel.Text = '采样率fs';

            app.fsEditField = uieditfield(app.Tab_5, 'numeric');
            app.fsEditField.ValueChangedFcn = @(src, evt) app.fsEditFieldValueChanged(src, evt);
            app.fsEditField.Position = [154 388 100 22];

            app.Label_45 = uilabel(app.Tab_5);
            app.Label_45.HorizontalAlignment = 'right';
            app.Label_45.Position = [66 421 53 22];
            app.Label_45.Text = '数据末值';

            app.EditField_16 = uieditfield(app.Tab_5, 'numeric');
            app.EditField_16.ValueChangedFcn = @(src, evt) app.EditField_16ValueChanged(src, evt);
            app.EditField_16.Position = [154 421 100 22];

            app.yButton = uibutton(app.Tab_5, 'push');
            app.yButton.ButtonPushedFcn = @(src, evt) app.yButtonPushed(src, evt);
            app.yButton.BackgroundColor = [0.0588 1 1];
            app.yButton.Position = [48 243 88 24];
            app.yButton.Text = 'y轴计算';

            app.zButton = uibutton(app.Tab_5, 'push');
            app.zButton.ButtonPushedFcn = @(src, evt) app.zButtonPushed(src, evt);
            app.zButton.BackgroundColor = [0.0588 1 1];
            app.zButton.Position = [48 145 88 24];
            app.zButton.Text = 'z轴计算';

            app.Label_46 = uilabel(app.Tab_5);
            app.Label_46.FontSize = 24;
            app.Label_46.FontColor = [0.1333 0.4392 0.6392];
            app.Label_46.Position = [60 639 198 31];
            app.Label_46.Text = '倾角剖面生成模块';

            app.Image_5 = uiimage(app.Tab_5);
            app.Image_5.Position = [1 633 43 43];
            app.Image_5.ImageSource = fullfile(imgPath, 'boatt.png');

            app.Label_48 = uilabel(app.Tab_5);
            app.Label_48.Position = [61 311 62 22];
            app.Label_48.Text = '最大倾角/°';

            app.Label_47 = uilabel(app.Tab_5);
            app.Label_47.BackgroundColor = [0.8 0.9882 0.9882];
            app.Label_47.HorizontalAlignment = 'right';
            app.Label_47.Position = [154 311 100 22];
            app.Label_47.Text = '';

            app.sLabel = uilabel(app.Tab_5);
            app.sLabel.Position = [61 278 63 22];
            app.sLabel.Text = '对应周期/s';

            app.Label_50 = uilabel(app.Tab_5);
            app.Label_50.BackgroundColor = [0.8 0.9882 0.9882];
            app.Label_50.HorizontalAlignment = 'right';
            app.Label_50.Position = [154 278 100 22];
            app.Label_50.Text = '';

            app.Label_51 = uilabel(app.Tab_5);
            app.Label_51.Position = [61 211 62 22];
            app.Label_51.Text = '最大倾角/°';

            app.Label_52 = uilabel(app.Tab_5);
            app.Label_52.BackgroundColor = [0.8 0.9882 0.9882];
            app.Label_52.HorizontalAlignment = 'right';
            app.Label_52.Position = [154 213 100 22];
            app.Label_52.Text = '';

            app.sLabel_2 = uilabel(app.Tab_5);
            app.sLabel_2.Position = [61 179 63 22];
            app.sLabel_2.Text = '对应周期/s';

            app.Label_53 = uilabel(app.Tab_5);
            app.Label_53.BackgroundColor = [0.8 0.9882 0.9882];
            app.Label_53.HorizontalAlignment = 'right';
            app.Label_53.Position = [154 179 100 22];
            app.Label_53.Text = '';

            app.Label_54 = uilabel(app.Tab_5);
            app.Label_54.Position = [61 109 62 22];
            app.Label_54.Text = '最大倾角/°';

            app.Label_55 = uilabel(app.Tab_5);
            app.Label_55.BackgroundColor = [0.8 0.9882 0.9882];
            app.Label_55.HorizontalAlignment = 'right';
            app.Label_55.Position = [154 109 100 22];
            app.Label_55.Text = '';

            app.sLabel_3 = uilabel(app.Tab_5);
            app.sLabel_3.Position = [61 81 63 22];
            app.sLabel_3.Text = '对应周期/s';

            app.Label_56 = uilabel(app.Tab_5);
            app.Label_56.BackgroundColor = [0.8 0.9882 0.9882];
            app.Label_56.HorizontalAlignment = 'right';
            app.Label_56.Position = [154 81 100 22];
            app.Label_56.Text = '';

            app.UIAxes10_15 = uiaxes(app.Tab_5);
            title(app.UIAxes10_15, 'x轴倾角时域数据');
            xlabel(app.UIAxes10_15, '时间/s');
            ylabel(app.UIAxes10_15, '角度/°');
            app.UIAxes10_15.Position = [271 455 330 216];

            app.UIAxes10_16 = uiaxes(app.Tab_5);
            title(app.UIAxes10_16, 'x轴连续角度变化与时间关系离散图');
            xlabel(app.UIAxes10_16, '时间/s');
            ylabel(app.UIAxes10_16, '角度/°');
            app.UIAxes10_16.Position = [600 455 330 216];

            app.UIAxes10_17 = uiaxes(app.Tab_5);
            title(app.UIAxes10_17, 'y轴倾角时域数据');
            xlabel(app.UIAxes10_17, '时间/s');
            ylabel(app.UIAxes10_17, '角度/°');
            app.UIAxes10_17.Position = [271 234 330 216];

            app.UIAxes10_18 = uiaxes(app.Tab_5);
            title(app.UIAxes10_18, 'y轴连续角度变化与时间关系离散图');
            xlabel(app.UIAxes10_18, '时间/s');
            ylabel(app.UIAxes10_18, '角度/°');
            app.UIAxes10_18.Position = [600 234 330 216];

            app.UIAxes10_19 = uiaxes(app.Tab_5);
            title(app.UIAxes10_19, 'z轴倾角时域数据');
            xlabel(app.UIAxes10_19, '时间/s');
            ylabel(app.UIAxes10_19, '角度/°');
            app.UIAxes10_19.Position = [271 13 330 216];

            app.UIAxes10_20 = uiaxes(app.Tab_5);
            title(app.UIAxes10_20, 'z轴连续角度变化与时间关系离散图');
            xlabel(app.UIAxes10_20, '时间/s');
            ylabel(app.UIAxes10_20, '角度/°');
            app.UIAxes10_20.Position = [600 13 330 216];

            app.UIAxes10_21 = uiaxes(app.Tab_5);
            title(app.UIAxes10_21, 'x轴试验谱');
            xlabel(app.UIAxes10_21, '时间/s');
            ylabel(app.UIAxes10_21, '角度/°');
            app.UIAxes10_21.Position = [933 455 330 216];

            app.UIAxes10_22 = uiaxes(app.Tab_5);
            title(app.UIAxes10_22, 'y轴试验谱');
            xlabel(app.UIAxes10_22, '时间/s');
            ylabel(app.UIAxes10_22, '角度/°');
            app.UIAxes10_22.Position = [933 234 330 216];

            app.UIAxes10_23 = uiaxes(app.Tab_5);
            title(app.UIAxes10_23, 'z轴试验谱');
            xlabel(app.UIAxes10_23, '时间/s');
            ylabel(app.UIAxes10_23, '角度/°');
            app.UIAxes10_23.Position = [933 13 330 216];

            % ===========================================
            % Tab_6: 设备应力综合分析 (NEW V2.0)
            % ===========================================
            app.Tab_6 = uitab(app.TabGroup);
            app.Tab_6.Title = '蒸汽压力';
            app.Tab_6.BackgroundColor = [1 1 1];
            app.Tab_6.ForegroundColor = [0 0.4471 0.7412];

            % 标题区域
            app.Label_74 = uilabel(app.Tab_6);
            app.Label_74.FontSize = 24;
            app.Label_74.FontColor = [0.1333 0.4392 0.6392];
            app.Label_74.Position = [60 680 450 31];
            app.Label_74.Text = '设备应力综合分析模块';

            app.Image_7 = uiimage(app.Tab_6);
            app.Image_7.Position = [1 673 43 43];
            app.Image_7.ImageSource = fullfile(imgPath, 'boatt.png');

            app.Label_76 = uilabel(app.Tab_6);
            app.Label_76.Position = [60 658 350 20];
            app.Label_76.Text = '选择数据并加载 | 支持多设备对比 | 6项统计输出';

            % 文件选择区
            app.Button_17 = uibutton(app.Tab_6, 'push');
            app.Button_17.ButtonPushedFcn = @(src, evt) app.Button_17Pushed(src, evt);
            app.Button_17.BackgroundColor = [0.0588 1 1];
            app.Button_17.Position = [10 633 88 24];
            app.Button_17.Text = '选择数据';

            app.EditField_17 = uieditfield(app.Tab_6, 'text');
            app.EditField_17.Position = [106 634 145 22];

            % 参数模块按钮
            app.Label_57 = uilabel(app.Tab_6);
            app.Label_57.Position = [10 605 241 22];
            app.Label_57.Text = '蒸汽压力 (MPa)';

            app.Button_18 = uibutton(app.Tab_6, 'push');
            app.Button_18.ButtonPushedFcn = @(src, evt) app.Button_18Pushed(src, evt);
            app.Button_18.BackgroundColor = [0 1 1];
            app.Button_18.Position = [10 579 241 24];
            app.Button_18.Text = '加载并分析';

            % 设备列表
            app.Label_58 = uilabel(app.Tab_6);
            app.Label_58.Position = [10 551 241 22];
            app.Label_58.Text = '设备类型列表';

            app.ListBox_1 = uilistbox(app.Tab_6);
            app.ListBox_1.Multiselect = 'on';
            app.ListBox_1.ValueChangedFcn = @(src, evt) app.ListBox_1ValueChanged(src, evt);
            app.ListBox_1.Position = [10 172 241 397];

            % Y轴调节
            app.Label_73 = uilabel(app.Tab_6);
            app.Label_73.Position = [10 142 241 22];
            app.Label_73.Text = 'Y轴范围调节 (最小 ─ 最大)';

            app.Label_59 = uilabel(app.Tab_6);
            app.Label_59.HorizontalAlignment = 'right';
            app.Label_59.Position = [10 116 28 22];
            app.Label_59.Text = '最小';

            app.EditField_18 = uieditfield(app.Tab_6, 'numeric');
            app.EditField_18.ValueChangedFcn = @(src, evt) app.EditField_18ValueChanged(src, evt);
            app.EditField_18.Position = [42 116 68 22];

            app.Label_60 = uilabel(app.Tab_6);
            app.Label_60.HorizontalAlignment = 'right';
            app.Label_60.Position = [114 116 28 22];
            app.Label_60.Text = '最大';

            app.EditField_19 = uieditfield(app.Tab_6, 'numeric');
            app.EditField_19.ValueChangedFcn = @(src, evt) app.EditField_19ValueChanged(src, evt);
            app.EditField_19.Position = [146 116 68 22];

            % 操作按钮
            app.Button_19 = uibutton(app.Tab_6, 'push');
            app.Button_19.ButtonPushedFcn = @(src, evt) app.Button_19Pushed(src, evt);
            app.Button_19.BackgroundColor = [0.8 0.9882 0.9882];
            app.Button_19.Position = [10 84 95 24];
            app.Button_19.Text = '导出图表';

            app.Button_20 = uibutton(app.Tab_6, 'push');
            app.Button_20.ButtonPushedFcn = @(src, evt) app.Button_20Pushed(src, evt);
            app.Button_20.BackgroundColor = [0.8 0.9882 0.9882];
            app.Button_20.Position = [113 84 95 24];
            app.Button_20.Text = '刷新图表';

            app.Button_25 = uibutton(app.Tab_6, 'push');
            app.Button_25.ButtonPushedFcn = @(src, evt) app.Button_25Pushed(src, evt);
            app.Button_25.BackgroundColor = [1 0.6 0.2];
            app.Button_25.Position = [10 50 241 26];
            app.Button_25.Text = '(Ctrl+点击可多选)';
            app.Button_25.Enable = 'off';

            % 绘图区
            app.UIAxes_24 = uiaxes(app.Tab_6);
            title(app.UIAxes_24, '设备应力时序对比');
            xlabel(app.UIAxes_24, '测量序号');
            ylabel(app.UIAxes_24, '数值');
            app.UIAxes_24.Position = [259 350 373 287];

            app.UIAxes_25 = uiaxes(app.Tab_6);
            title(app.UIAxes_25, '应力分布分析');
            xlabel(app.UIAxes_25, '设备');
            ylabel(app.UIAxes_25, '数值');
            app.UIAxes_25.Position = [259 73 373 269];

            % 结果区
            app.UITable_2 = uitable(app.Tab_6);
            app.UITable_2.Position = [640 73 630 498];
            app.UITable_2.ColumnName = {'max', 'min', 'mean', 'rms', 'var', 'std'};

            app.Label_61 = uilabel(app.Tab_6);
            app.Label_61.Position = [640 645 630 22];
            app.Label_61.Text = '统计结果(6项)';

            app.Label_62 = uilabel(app.Tab_6);
            app.Label_62.Position = [640 621 630 22];
            app.Label_62.Text = '当前模块: 未加载';

            app.Label_63 = uilabel(app.Tab_6);
            app.Label_63.Position = [640 597 315 22];
            app.Label_63.Text = '数据条数: 0';

            app.Label_64 = uilabel(app.Tab_6);
            app.Label_64.Position = [955 597 315 22];
            app.Label_64.Text = '设备类型数: 0';

            % 状态栏
            app.Label_66 = uilabel(app.Tab_6);
            app.Label_66.Position = [42 20 550 22];
            app.Label_66.Text = '就绪';

            % ===========================================
            % Tab_7: 蒸汽流量 (m3/h)
            % ===========================================
            app.Tab_7 = uitab(app.TabGroup);
            app.Tab_7.Title = '蒸汽流量';
            app.Tab_7.BackgroundColor = [1 1 1];
            app.Tab_7.ForegroundColor = [0 0.4471 0.7412];

            app.Label_78 = uilabel(app.Tab_7);
            app.Label_78.FontSize = 24;
            app.Label_78.FontColor = [0.1333 0.4392 0.6392];
            app.Label_78.Position = [60 680 450 31];
            app.Label_78.Text = '蒸汽流量 综合分析模块';

            app.Image_8 = uiimage(app.Tab_7);
            app.Image_8.Position = [1 673 43 43];
            app.Image_8.ImageSource = fullfile(imgPath, 'boatt.png');

            app.Label_79 = uilabel(app.Tab_7);
            app.Label_79.Position = [60 658 350 20];
            app.Label_79.Text = '选择数据并加载 | 支持多设备对比 | 6项统计输出';

            app.Button_26 = uibutton(app.Tab_7, 'push');
            app.Button_26.ButtonPushedFcn = @(src, evt) app.Button_26Pushed(src, evt);
            app.Button_26.BackgroundColor = [0.0588 1 1];
            app.Button_26.Position = [10 633 88 24];
            app.Button_26.Text = '选择数据';

            app.EditField_20 = uieditfield(app.Tab_7, 'text');
            app.EditField_20.Position = [106 634 145 22];

            app.Label_200 = uilabel(app.Tab_7);
            app.Label_200.Position = [10 605 241 22];
            app.Label_200.Text = '蒸汽流量 (m3/h)';

            app.Button_27 = uibutton(app.Tab_7, 'push');
            app.Button_27.ButtonPushedFcn = @(src, evt) app.Button_27Pushed(src, evt);
            app.Button_27.BackgroundColor = [0 1 1];
            app.Button_27.Position = [10 579 241 24];
            app.Button_27.Text = '加载并分析';

            app.Label_201 = uilabel(app.Tab_7);
            app.Label_201.Position = [10 551 241 22];
            app.Label_201.Text = '设备类型列表';

            app.ListBox_2 = uilistbox(app.Tab_7);
            app.ListBox_2.Multiselect = 'on';
            app.ListBox_2.ValueChangedFcn = @(src, evt) app.ListBox_2ValueChanged(src, evt);
            app.ListBox_2.Position = [10 172 241 397];

            app.Label_80 = uilabel(app.Tab_7);
            app.Label_80.Position = [10 142 241 22];
            app.Label_80.Text = 'Y轴范围调节 (最小 ─ 最大)';

            app.Label_202 = uilabel(app.Tab_7);
            app.Label_202.HorizontalAlignment = 'right';
            app.Label_202.Position = [10 116 28 22];
            app.Label_202.Text = '最小';

            app.EditField_28 = uieditfield(app.Tab_7, 'numeric');
            app.EditField_28.ValueChangedFcn = @(src, evt) app.EditField_28ValueChanged(src, evt);
            app.EditField_28.Position = [42 116 68 22];

            app.Label_203 = uilabel(app.Tab_7);
            app.Label_203.HorizontalAlignment = 'right';
            app.Label_203.Position = [114 116 28 22];
            app.Label_203.Text = '最大';

            app.EditField_29 = uieditfield(app.Tab_7, 'numeric');
            app.EditField_29.ValueChangedFcn = @(src, evt) app.EditField_29ValueChanged(src, evt);
            app.EditField_29.Position = [146 116 68 22];

            app.Button_28 = uibutton(app.Tab_7, 'push');
            app.Button_28.ButtonPushedFcn = @(src, evt) app.Button_28Pushed(src, evt);
            app.Button_28.BackgroundColor = [0.8 0.9882 0.9882];
            app.Button_28.Position = [10 84 95 24];
            app.Button_28.Text = '导出图表';

            app.Button_29 = uibutton(app.Tab_7, 'push');
            app.Button_29.ButtonPushedFcn = @(src, evt) app.Button_29Pushed(src, evt);
            app.Button_29.BackgroundColor = [0.8 0.9882 0.9882];
            app.Button_29.Position = [113 84 95 24];
            app.Button_29.Text = '刷新图表';

            app.Button_30 = uibutton(app.Tab_7, 'push');
            app.Button_30.Text = '(Ctrl+点击可多选)';
            app.Button_30.Enable = 'off';
            app.Button_30.Position = [10 50 241 26];

            app.UIAxes_26 = uiaxes(app.Tab_7);
            title(app.UIAxes_26, '设备应力时序对比');
            xlabel(app.UIAxes_26, '测量序号');
            ylabel(app.UIAxes_26, '数值');
            app.UIAxes_26.Position = [259 350 373 287];

            app.UIAxes_27 = uiaxes(app.Tab_7);
            title(app.UIAxes_27, '应力分布分析');
            xlabel(app.UIAxes_27, '设备');
            ylabel(app.UIAxes_27, '数值');
            app.UIAxes_27.Position = [259 73 373 269];

            app.UITable_3 = uitable(app.Tab_7);
            app.UITable_3.Position = [640 73 630 498];
            app.UITable_3.ColumnName = {'最大值','最小值','平均值','均方根值','方差','标准差'};

            app.Label_67 = uilabel(app.Tab_7);
            app.Label_67.Position = [640 645 630 22];
            app.Label_67.Text = '统计结果(6项)';

            app.Label_68 = uilabel(app.Tab_7);
            app.Label_68.Position = [640 621 630 22];
            app.Label_68.Text = '当前模块: 未加载';

            app.Label_69 = uilabel(app.Tab_7);
            app.Label_69.Position = [640 597 315 22];
            app.Label_69.Text = '数据条数: 0';

            app.Label_70 = uilabel(app.Tab_7);
            app.Label_70.Position = [955 597 315 22];
            app.Label_70.Text = '设备类型数: 0';

            app.Label_71 = uilabel(app.Tab_7);
            app.Label_71.Position = [42 20 550 22];
            app.Label_71.Text = '就绪';
            % ===========================================
            % Tab_8: 蒸汽颗粒物浓度 (%)
            % ===========================================
            app.Tab_8 = uitab(app.TabGroup);
            app.Tab_8.Title = '蒸汽颗粒物浓度';
            app.Tab_8.BackgroundColor = [1 1 1];
            app.Tab_8.ForegroundColor = [0 0.4471 0.7412];

            app.Label_82 = uilabel(app.Tab_8);
            app.Label_82.FontSize = 24;
            app.Label_82.FontColor = [0.1333 0.4392 0.6392];
            app.Label_82.Position = [60 680 450 31];
            app.Label_82.Text = '蒸汽颗粒物浓度 综合分析模块';

            app.Image_9 = uiimage(app.Tab_8);
            app.Image_9.Position = [1 673 43 43];
            app.Image_9.ImageSource = fullfile(imgPath, 'boatt.png');

            app.Label_83 = uilabel(app.Tab_8);
            app.Label_83.Position = [60 658 350 20];
            app.Label_83.Text = '选择数据并加载 | 支持多设备对比 | 6项统计输出';

            app.Button_31 = uibutton(app.Tab_8, 'push');
            app.Button_31.ButtonPushedFcn = @(src, evt) app.Button_31Pushed(src, evt);
            app.Button_31.BackgroundColor = [0.0588 1 1];
            app.Button_31.Position = [10 633 88 24];
            app.Button_31.Text = '选择数据';

            app.EditField_21 = uieditfield(app.Tab_8, 'text');
            app.EditField_21.Position = [106 634 145 22];

            app.Label_204 = uilabel(app.Tab_8);
            app.Label_204.Position = [10 605 241 22];
            app.Label_204.Text = '蒸汽颗粒物浓度 (%)';

            app.Button_32 = uibutton(app.Tab_8, 'push');
            app.Button_32.ButtonPushedFcn = @(src, evt) app.Button_32Pushed(src, evt);
            app.Button_32.BackgroundColor = [0 1 1];
            app.Button_32.Position = [10 579 241 24];
            app.Button_32.Text = '加载并分析';

            app.Label_205 = uilabel(app.Tab_8);
            app.Label_205.Position = [10 551 241 22];
            app.Label_205.Text = '设备类型列表';

            app.ListBox_3 = uilistbox(app.Tab_8);
            app.ListBox_3.Multiselect = 'on';
            app.ListBox_3.ValueChangedFcn = @(src, evt) app.ListBox_3ValueChanged(src, evt);
            app.ListBox_3.Position = [10 172 241 397];

            app.Label_84 = uilabel(app.Tab_8);
            app.Label_84.Position = [10 142 241 22];
            app.Label_84.Text = 'Y轴范围调节 (最小 ─ 最大)';

            app.Label_206 = uilabel(app.Tab_8);
            app.Label_206.HorizontalAlignment = 'right';
            app.Label_206.Position = [10 116 28 22];
            app.Label_206.Text = '最小';

            app.EditField_31 = uieditfield(app.Tab_8, 'numeric');
            app.EditField_31.ValueChangedFcn = @(src, evt) app.EditField_31ValueChanged(src, evt);
            app.EditField_31.Position = [42 116 68 22];

            app.Label_207 = uilabel(app.Tab_8);
            app.Label_207.HorizontalAlignment = 'right';
            app.Label_207.Position = [114 116 28 22];
            app.Label_207.Text = '最大';

            app.EditField_32 = uieditfield(app.Tab_8, 'numeric');
            app.EditField_32.ValueChangedFcn = @(src, evt) app.EditField_32ValueChanged(src, evt);
            app.EditField_32.Position = [146 116 68 22];

            app.Button_33 = uibutton(app.Tab_8, 'push');
            app.Button_33.ButtonPushedFcn = @(src, evt) app.Button_33Pushed(src, evt);
            app.Button_33.BackgroundColor = [0.8 0.9882 0.9882];
            app.Button_33.Position = [10 84 95 24];
            app.Button_33.Text = '导出图表';

            app.Button_34 = uibutton(app.Tab_8, 'push');
            app.Button_34.ButtonPushedFcn = @(src, evt) app.Button_34Pushed(src, evt);
            app.Button_34.BackgroundColor = [0.8 0.9882 0.9882];
            app.Button_34.Position = [113 84 95 24];
            app.Button_34.Text = '刷新图表';

            app.Button_35 = uibutton(app.Tab_8, 'push');
            app.Button_35.Text = '(Ctrl+点击可多选)';
            app.Button_35.Enable = 'off';
            app.Button_35.Position = [10 50 241 26];

            app.UIAxes_28 = uiaxes(app.Tab_8);
            title(app.UIAxes_28, '设备应力时序对比');
            xlabel(app.UIAxes_28, '测量序号');
            ylabel(app.UIAxes_28, '数值');
            app.UIAxes_28.Position = [259 350 373 287];

            app.UIAxes_29 = uiaxes(app.Tab_8);
            title(app.UIAxes_29, '应力分布分析');
            xlabel(app.UIAxes_29, '设备');
            ylabel(app.UIAxes_29, '数值');
            app.UIAxes_29.Position = [259 73 373 269];

            app.UITable_4 = uitable(app.Tab_8);
            app.UITable_4.Position = [640 73 630 498];
            app.UITable_4.ColumnName = {'最大值','最小值','平均值','均方根值','方差','标准差'};

            app.Label_72 = uilabel(app.Tab_8);
            app.Label_72.Position = [640 645 630 22];
            app.Label_72.Text = '统计结果(6项)';

            app.Label_208 = uilabel(app.Tab_8);
            app.Label_208.Position = [640 621 630 22];
            app.Label_208.Text = '当前模块: 未加载';

            app.Label_209 = uilabel(app.Tab_8);
            app.Label_209.Position = [640 597 315 22];
            app.Label_209.Text = '数据条数: 0';

            app.Label_210 = uilabel(app.Tab_8);
            app.Label_210.Position = [955 597 315 22];
            app.Label_210.Text = '设备类型数: 0';

            app.Label_211 = uilabel(app.Tab_8);
            app.Label_211.Position = [42 20 550 22];
            app.Label_211.Text = '就绪';
            % ===========================================
            % Tab_9: 盐雾浓度 (mg/m3)
            % ===========================================
            app.Tab_9 = uitab(app.TabGroup);
            app.Tab_9.Title = '盐雾浓度';
            app.Tab_9.BackgroundColor = [1 1 1];
            app.Tab_9.ForegroundColor = [0 0.4471 0.7412];

            app.Label_86 = uilabel(app.Tab_9);
            app.Label_86.FontSize = 24;
            app.Label_86.FontColor = [0.1333 0.4392 0.6392];
            app.Label_86.Position = [60 680 450 31];
            app.Label_86.Text = '盐雾浓度 综合分析模块';

            app.Image_10 = uiimage(app.Tab_9);
            app.Image_10.Position = [1 673 43 43];
            app.Image_10.ImageSource = fullfile(imgPath, 'boatt.png');

            app.Label_87 = uilabel(app.Tab_9);
            app.Label_87.Position = [60 658 350 20];
            app.Label_87.Text = '选择数据并加载 | 支持多设备对比 | 6项统计输出';

            app.Button_36 = uibutton(app.Tab_9, 'push');
            app.Button_36.ButtonPushedFcn = @(src, evt) app.Button_36Pushed(src, evt);
            app.Button_36.BackgroundColor = [0.0588 1 1];
            app.Button_36.Position = [10 633 88 24];
            app.Button_36.Text = '选择数据';

            app.EditField_22 = uieditfield(app.Tab_9, 'text');
            app.EditField_22.Position = [106 634 145 22];

            app.Label_212 = uilabel(app.Tab_9);
            app.Label_212.Position = [10 605 241 22];
            app.Label_212.Text = '盐雾浓度 (mg/m3)';

            app.Button_37 = uibutton(app.Tab_9, 'push');
            app.Button_37.ButtonPushedFcn = @(src, evt) app.Button_37Pushed(src, evt);
            app.Button_37.BackgroundColor = [0 1 1];
            app.Button_37.Position = [10 579 241 24];
            app.Button_37.Text = '加载并分析';

            app.Label_213 = uilabel(app.Tab_9);
            app.Label_213.Position = [10 551 241 22];
            app.Label_213.Text = '设备类型列表';

            app.ListBox_4 = uilistbox(app.Tab_9);
            app.ListBox_4.Multiselect = 'on';
            app.ListBox_4.ValueChangedFcn = @(src, evt) app.ListBox_4ValueChanged(src, evt);
            app.ListBox_4.Position = [10 172 241 397];

            app.Label_88 = uilabel(app.Tab_9);
            app.Label_88.Position = [10 142 241 22];
            app.Label_88.Text = 'Y轴范围调节 (最小 ─ 最大)';

            app.Label_214 = uilabel(app.Tab_9);
            app.Label_214.HorizontalAlignment = 'right';
            app.Label_214.Position = [10 116 28 22];
            app.Label_214.Text = '最小';

            app.EditField_33 = uieditfield(app.Tab_9, 'numeric');
            app.EditField_33.ValueChangedFcn = @(src, evt) app.EditField_33ValueChanged(src, evt);
            app.EditField_33.Position = [42 116 68 22];

            app.Label_215 = uilabel(app.Tab_9);
            app.Label_215.HorizontalAlignment = 'right';
            app.Label_215.Position = [114 116 28 22];
            app.Label_215.Text = '最大';

            app.EditField_34 = uieditfield(app.Tab_9, 'numeric');
            app.EditField_34.ValueChangedFcn = @(src, evt) app.EditField_34ValueChanged(src, evt);
            app.EditField_34.Position = [146 116 68 22];

            app.Button_38 = uibutton(app.Tab_9, 'push');
            app.Button_38.ButtonPushedFcn = @(src, evt) app.Button_38Pushed(src, evt);
            app.Button_38.BackgroundColor = [0.8 0.9882 0.9882];
            app.Button_38.Position = [10 84 95 24];
            app.Button_38.Text = '导出图表';

            app.Button_39 = uibutton(app.Tab_9, 'push');
            app.Button_39.ButtonPushedFcn = @(src, evt) app.Button_39Pushed(src, evt);
            app.Button_39.BackgroundColor = [0.8 0.9882 0.9882];
            app.Button_39.Position = [113 84 95 24];
            app.Button_39.Text = '刷新图表';

            app.Button_40 = uibutton(app.Tab_9, 'push');
            app.Button_40.Text = '(Ctrl+点击可多选)';
            app.Button_40.Enable = 'off';
            app.Button_40.Position = [10 50 241 26];

            app.UIAxes_30 = uiaxes(app.Tab_9);
            title(app.UIAxes_30, '设备应力时序对比');
            xlabel(app.UIAxes_30, '测量序号');
            ylabel(app.UIAxes_30, '数值');
            app.UIAxes_30.Position = [259 350 373 287];

            app.UIAxes_31 = uiaxes(app.Tab_9);
            title(app.UIAxes_31, '应力分布分析');
            xlabel(app.UIAxes_31, '设备');
            ylabel(app.UIAxes_31, '数值');
            app.UIAxes_31.Position = [259 73 373 269];

            app.UITable_5 = uitable(app.Tab_9);
            app.UITable_5.Position = [640 73 630 498];
            app.UITable_5.ColumnName = {'最大值','最小值','平均值','均方根值','方差','标准差'};

            app.Label_77 = uilabel(app.Tab_9);
            app.Label_77.Position = [640 645 630 22];
            app.Label_77.Text = '统计结果(6项)';

            app.Label_216 = uilabel(app.Tab_9);
            app.Label_216.Position = [640 621 630 22];
            app.Label_216.Text = '当前模块: 未加载';

            app.Label_217 = uilabel(app.Tab_9);
            app.Label_217.Position = [640 597 315 22];
            app.Label_217.Text = '数据条数: 0';

            app.Label_218 = uilabel(app.Tab_9);
            app.Label_218.Position = [955 597 315 22];
            app.Label_218.Text = '设备类型数: 0';

            app.Label_219 = uilabel(app.Tab_9);
            app.Label_219.Position = [42 20 550 22];
            app.Label_219.Text = '就绪';
            % ===========================================
            % Tab_10: 氧浓度 (%)
            % ===========================================
            app.Tab_10 = uitab(app.TabGroup);
            app.Tab_10.Title = '氧浓度';
            app.Tab_10.BackgroundColor = [1 1 1];
            app.Tab_10.ForegroundColor = [0 0.4471 0.7412];

            app.Label_90 = uilabel(app.Tab_10);
            app.Label_90.FontSize = 24;
            app.Label_90.FontColor = [0.1333 0.4392 0.6392];
            app.Label_90.Position = [60 680 450 31];
            app.Label_90.Text = '氧浓度 综合分析模块';

            app.Image_11 = uiimage(app.Tab_10);
            app.Image_11.Position = [1 673 43 43];
            app.Image_11.ImageSource = fullfile(imgPath, 'boatt.png');

            app.Label_91 = uilabel(app.Tab_10);
            app.Label_91.Position = [60 658 350 20];
            app.Label_91.Text = '选择数据并加载 | 支持多设备对比 | 6项统计输出';

            app.Button_41 = uibutton(app.Tab_10, 'push');
            app.Button_41.ButtonPushedFcn = @(src, evt) app.Button_41Pushed(src, evt);
            app.Button_41.BackgroundColor = [0.0588 1 1];
            app.Button_41.Position = [10 633 88 24];
            app.Button_41.Text = '选择数据';

            app.EditField_23 = uieditfield(app.Tab_10, 'text');
            app.EditField_23.Position = [106 634 145 22];

            app.Label_220 = uilabel(app.Tab_10);
            app.Label_220.Position = [10 605 241 22];
            app.Label_220.Text = '氧浓度 (%)';

            app.Button_42 = uibutton(app.Tab_10, 'push');
            app.Button_42.ButtonPushedFcn = @(src, evt) app.Button_42Pushed(src, evt);
            app.Button_42.BackgroundColor = [0 1 1];
            app.Button_42.Position = [10 579 241 24];
            app.Button_42.Text = '加载并分析';

            app.Label_221 = uilabel(app.Tab_10);
            app.Label_221.Position = [10 551 241 22];
            app.Label_221.Text = '设备类型列表';

            app.ListBox_5 = uilistbox(app.Tab_10);
            app.ListBox_5.Multiselect = 'on';
            app.ListBox_5.ValueChangedFcn = @(src, evt) app.ListBox_5ValueChanged(src, evt);
            app.ListBox_5.Position = [10 172 241 397];

            app.Label_92 = uilabel(app.Tab_10);
            app.Label_92.Position = [10 142 241 22];
            app.Label_92.Text = 'Y轴范围调节 (最小 ─ 最大)';

            app.Label_222 = uilabel(app.Tab_10);
            app.Label_222.HorizontalAlignment = 'right';
            app.Label_222.Position = [10 116 28 22];
            app.Label_222.Text = '最小';

            app.EditField_35 = uieditfield(app.Tab_10, 'numeric');
            app.EditField_35.ValueChangedFcn = @(src, evt) app.EditField_35ValueChanged(src, evt);
            app.EditField_35.Position = [42 116 68 22];

            app.Label_223 = uilabel(app.Tab_10);
            app.Label_223.HorizontalAlignment = 'right';
            app.Label_223.Position = [114 116 28 22];
            app.Label_223.Text = '最大';

            app.EditField_36 = uieditfield(app.Tab_10, 'numeric');
            app.EditField_36.ValueChangedFcn = @(src, evt) app.EditField_36ValueChanged(src, evt);
            app.EditField_36.Position = [146 116 68 22];

            app.Button_43 = uibutton(app.Tab_10, 'push');
            app.Button_43.ButtonPushedFcn = @(src, evt) app.Button_43Pushed(src, evt);
            app.Button_43.BackgroundColor = [0.8 0.9882 0.9882];
            app.Button_43.Position = [10 84 95 24];
            app.Button_43.Text = '导出图表';

            app.Button_44 = uibutton(app.Tab_10, 'push');
            app.Button_44.ButtonPushedFcn = @(src, evt) app.Button_44Pushed(src, evt);
            app.Button_44.BackgroundColor = [0.8 0.9882 0.9882];
            app.Button_44.Position = [113 84 95 24];
            app.Button_44.Text = '刷新图表';

            app.Button_45 = uibutton(app.Tab_10, 'push');
            app.Button_45.Text = '(Ctrl+点击可多选)';
            app.Button_45.Enable = 'off';
            app.Button_45.Position = [10 50 241 26];

            app.UIAxes_32 = uiaxes(app.Tab_10);
            title(app.UIAxes_32, '设备应力时序对比');
            xlabel(app.UIAxes_32, '测量序号');
            ylabel(app.UIAxes_32, '数值');
            app.UIAxes_32.Position = [259 350 373 287];

            app.UIAxes_33 = uiaxes(app.Tab_10);
            title(app.UIAxes_33, '应力分布分析');
            xlabel(app.UIAxes_33, '设备');
            ylabel(app.UIAxes_33, '数值');
            app.UIAxes_33.Position = [259 73 373 269];

            app.UITable_6 = uitable(app.Tab_10);
            app.UITable_6.Position = [640 73 630 498];
            app.UITable_6.ColumnName = {'最大值','最小值','平均值','均方根值','方差','标准差'};

            app.Label_222_t10 = uilabel(app.Tab_10);
            app.Label_222_t10.Position = [640 645 630 22];
            app.Label_222_t10.Text = '统计结果(6项)';

            app.Label_223_t10 = uilabel(app.Tab_10);
            app.Label_223_t10.Position = [640 621 630 22];
            app.Label_223_t10.Text = '当前模块: 未加载';

            app.Label_224 = uilabel(app.Tab_10);
            app.Label_224.Position = [640 597 315 22];
            app.Label_224.Text = '数据条数: 0';

            app.Label_225 = uilabel(app.Tab_10);
            app.Label_225.Position = [955 597 315 22];
            app.Label_225.Text = '设备类型数: 0';

            app.Label_226 = uilabel(app.Tab_10);
            app.Label_226.Position = [42 20 550 22];
            app.Label_226.Text = '就绪';

            % --- Show Figure ---
            app.UIFigure.Visible = 'on';
        end

    end

    % ================================================================
    % CONSTRUCTOR & DESTRUCTOR
    % ================================================================
    methods (Access = public)

        function app = BoatMain_V2
            createComponents(app);
            registerApp(app, app.UIFigure);
            app.curTabIdx = 1;

            if nargout == 0
                clear app
            end
        end

    end

    methods (Access = public)
        function delete(app)
            delete(app.UIFigure);
        end
    end

end
